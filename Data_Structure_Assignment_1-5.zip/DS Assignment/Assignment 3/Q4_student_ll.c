
#include <stdio.h>
#include <stdlib.h>
#include<string.h>

struct node
{
	char name[15];
	int pnr;
	struct node *next;
};

void insert_end(struct node **,char [],int);
void insert_beg(struct node **,char [],int);
void insert_pos(struct node **,char [],int,int);
void display(struct node *);
int count(struct node *);
void delete_end(struct node **);
void delete_beg(struct node **);
void delete_pos(struct node **,int);
void delete_element(struct node **,int);
void reverse(struct node *);
void free_element(struct node *);


int main(void) {
    int choice,pnr,pos,pnr1;
    char name[15];
    struct node *head=NULL;
    while(1)
    {
    	printf("-------------------------------------------\n");
    	printf("1 for insert at end the element\n");
    	printf("2 for insert at beg the element\n");
    	printf("3 for insert at position the element\n");
    	printf("4 for display the element\n");
    	printf("5 for list the count no of element\n");
    	printf("6 for delete from end the element\n");
    	printf("7 for delete from beg the element\n");
    	printf("8 for delete from position the element\n");
    	printf("9 for delete by element\n");
    	printf("10 for reverse the the element\n");
    	printf("11 for free all the element\n");
    	printf("-------------------------------------------\n");
    	printf("enter the choice\n");
    	scanf("%d",&choice);
    	switch(choice)
    	{
    			case 1: printf("enter the name of student\n");
    			        scanf("%s",name);
    				    printf("enter the pnr no\n");
    	                scanf("%d",&pnr);
    	                insert_end(&head,name,pnr);
    	                break;
    	        case 2:printf("enter the name of student\n");
		               scanf("%s",name);
			           printf("enter the pnr no\n");
                       scanf("%d",&pnr);
    	               insert_beg(&head,name,pnr);
    	               break;
    	        case 3:printf("enter the name of student\n");
		               scanf("%s",name);
			           printf("enter the pnr no\n");
                       scanf("%d",&pnr);
                       printf("enter the position of element\n");
                       scanf("%d",&pos);
    	               insert_pos(&head,name,pnr,pos);
    	               break;
    	        case 4:display(head);
    	               break;
    	        case 5:printf("count=%d\n",count(head));
    	               break;
    	        case 6:delete_beg(&head);
    	               break;
    	        case 7:delete_end(&head);
    	               break;
    	        case 8:printf("enter the position of element\n");
                       scanf("%d",&pos);
                       delete_pos(&head,pos);
                       break;
    	        case 9:printf("enter the pnr of student\n");
    	               scanf("%d",&pnr1);
    	        	   printf("delete pnr=%d\n",delete_element(&head,pnr1));
    	               break;
    	        case 10:reverse(head);
    	                break;
    	        case 11:free_element(head);
    	                break;
    	        case 12:exit(0);
    	                break;
    	        default:printf("try again\n");
    	                break;
    	}
    }
	return EXIT_SUCCESS;
}

void insert_end(struct node **p,char name[15],int pnr)
{
	    struct node *temp,*t;
	    t=*p;
	    temp=(struct node *)malloc(sizeof(struct node));
	    strcpy(temp->name,name);
	    temp->pnr=pnr;
	    temp->next=NULL;
	    if(*p==NULL)
	    {
	    *p=temp;
	    }
	    else
	    {
	        while(t->next!=NULL)
	        {
	            t=t->next;
	         }
		t->next=temp;
	    }
}
void insert_beg(struct node **p,char name[15],int pnr)
{
	struct node *temp,*t;
	    t=*p;
	    temp=(struct node *)malloc(sizeof(struct node));
	    strcpy(temp->name,name);
	    temp->pnr=pnr;
	    temp->next=NULL;
	    if(*p==NULL)
	    {
	    *p=temp;
	    }
	    else
	    {
	        temp->next=*p;
	        *p=temp;
	    }
}
void insert_pos(struct node **p,char name[15],int pnr,int pos)
{
	struct node *temp,*t;
	    t=*p;
	    int i=1;
	    temp=(struct node *)malloc(sizeof(struct node));
	    strcpy(temp->name,name);
	   	temp->pnr=pnr;
	    temp->next=NULL;
	    if(pos==1)
	    {
	        insert_beg(p,name,pnr);
	    }
	    else{
	    while(i<pos-1)
	    {
	        t=t->next;
	        i++;
	    }
	    temp->next=t->next;
	    t->next=temp;
	    }
}
void display(struct node *q)
{
	if(q==NULL)
	printf("no nodes are connected\n");
	while(q!=NULL)
	    {
	        printf("%s",q->name);
	        printf(" =%d",q->pnr);
	        printf("\n");
	        q=q->next;
	    }
}
int count(struct node *q)
{
	int count=0;
		while(q!=NULL)
		{
			q=q->next;
			count++;
		}
		return count;
}
void delete_end(struct node **p)
{
	 struct node *t1,*t2;
	    t1=*p;
	    t2=NULL;
	    if(*p==NULL)
	    printf("no nodes are aviliable\n");
	    else{
	        while(t1->next!=NULL)
	        {
	            t2=t1;
	            t1=t1->next;
	        }
	        t2->next=NULL;
	        free(t1);
    }
}
void delete_beg(struct node **p)
{
	struct node *t1;
	   t1=*p;
	   if(*p==NULL)
	   printf("no nodes\n");
	   else
	   {
	     *p=t1->next;
	     free(t1);
	   }
}
void delete_pos(struct node **p,int pos)
{
	 struct node *t1,*t2;
	    int i=1;
	    t1=*p;
	    t2=NULL;
	    if(pos==1)
	    {
	        delete_beg(p);
	    }
	    else{
	        while(i<pos)
	        {
	            t2=t1;
	            t1=t1->next;
	            i++;
	        }
	        t2->next=t1->next;
	        free(t1);
	    }
}
void delete_element(struct node **p,int pnr1)
{
	struct node *t,*k;
	t=*p;
	k=NULL;
	if(t->pnr==pnr1)
	{
		*p=t->next;
		free(t);
	}
	else
	{
		while(t!=NULL && t->pnr!=pnr1)
		{
			k=t;
			t=t->next;
		}
		k->next=t->next;
				free(t);
	}
}
void reverse(struct node *p)
{
	if(p==NULL)
	{
		return;
	}
	   reverse(p->next);
	   printf("%s",p->name);
	   printf(" =%d\n",p->pnr);
	   printf("\n");
}

void free_element(struct node *p)
{
	struct node *t,*store;
	t=p;
	while(t!=NULL)
	{
		store=t->next;
		free(t);
		t=store;
	}
}










































