
#include<stdio.h>
int main()
{
    int size,z;
    printf("enter the size of an array\n");
    scanf("%d",&size);
    int arr[size];
    printf("enter the element of an array\n");
    for(int i=0;i<size;i++)
    {
      scanf("%d",&arr[i]);
    }
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");

    int temp=size-1;
    while(temp)
    {
        for(int i=0;i<size;i++)
      {
         if(arr[i]>arr[i+1])
           {
             z=arr[i];
             arr[i]=arr[i+1];
             arr[i+1]=z;
           }
       }
       temp--;
    }
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");
}



