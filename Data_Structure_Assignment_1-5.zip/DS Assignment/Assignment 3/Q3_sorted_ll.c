
#include <stdio.h>
#include <stdlib.h>

typedef struct NODE{
	int data;
	struct NODE *next;
}NODE_t;

NODE_t*get_node(int val);
void display(NODE_t *);
void reverse_display(NODE_t*);
void insert(NODE_t **,int val,int pos,int *count);
void insert_at_beg(NODE_t**,int val,int *count);
void insert_at_end(NODE_t**,int val,int *count);
void delete_from_end(NODE_t**,int *count);
void delete_from_beg(NODE_t**,int *count);
void delete_from_pos(NODE_t**,int val,int *count);
int check_duplicate(NODE_t*head_ptr,int val);


int main(void) {
	NODE_t *head=NULL;
	int count=0,choice,val,pos;

	while(1){
		printf("============================================\n");
		printf("0 - Display\n");
		printf("1 - Insert\n");
		printf("2 - Delete from end\n");
		printf("3 - Delete from beg\n");
		printf("4 - Delete from pos\n");
		printf("5 - Reverse Display\n");
		printf("6 - Node count\n");
		scanf("%d",&choice);

		switch(choice)
		{
		case 0:
				display(head);
				break;
		case 1:
				printf("Enter element to insert: ");
				scanf("%d",&val);
				printf("Enter position to insert: ");
				scanf("%d",&pos);
				insert(&head,val,pos,&count);
				break;
		case 2:
				delete_from_end(&head,&count);
				break;
		case 3:
				delete_from_beg(&head,&count);
				break;
		case 4:
				printf("Enter position to delete : ");
				scanf("%d",&pos);
				delete_from_pos(&head,pos,&count);
				break;
		case 5:
				reverse_display(head);
				break;
		case 6:
				printf("node count = %d\n",count);
				break;
		default:
				printf("Invalid INPUT!!!!\n");
				break;



		}
	}
	return EXIT_SUCCESS;
}

int check_duplicate(NODE_t *head_ptr,int val)
{
	while(head_ptr!=NULL)
	{
		if(head_ptr->data==val)
		{
			printf("Duplicate Found!!!\n");
			return 1;
		}
		head_ptr=head_ptr->next;
	}
	return 0;
}

NODE_t*get_node(int val)
{
	NODE_t*temp=(NODE_t*)malloc(sizeof(NODE_t));
	temp->data=val;
	temp->next=NULL;
	return temp;
}

void display(NODE_t *head_ptr){
	while(head_ptr!=NULL)
	{
		printf("%d ",head_ptr->data);
		head_ptr=head_ptr->next;
	}
	printf("\n");
}
void reverse_display(NODE_t*head_ptr){
	if(head_ptr!=NULL)
	{
		reverse_display(head_ptr->next);
		printf("%d ",head_ptr->data);
	}
	else
	{
		return;
	}
}
void insert(NODE_t **head_ptr_ptr,int val,int pos,int *count)
{

		if(check_duplicate(*head_ptr_ptr, val))
		{
			return;
		}
		if(pos==0)
		{
			insert_at_beg(head_ptr_ptr,val,count);
			return;
		}
		else if(pos >= *count)
		{
			insert_at_end(head_ptr_ptr,val,count);
			return;
		}
		else
		{
			NODE_t*temp_head=*head_ptr_ptr;
			for(int i=1;i<pos;i++)
			{
				temp_head=temp_head->next;
			}
			NODE_t*new_node=get_node(val);
			new_node->next=temp_head->next;
			temp_head->next=new_node;
			(*count)++;
		}
}
void insert_at_beg(NODE_t**head_ptr_ptr,int val,int *count){
	if(*head_ptr_ptr==NULL)
	{
		*head_ptr_ptr=get_node(val);
		(*count)++;
	}
	else
	{
		NODE_t*new_node=get_node(val);
		new_node->next=*head_ptr_ptr;
		*head_ptr_ptr=new_node;
		(*count)++;
	}
}
void insert_at_end(NODE_t**head_ptr_ptr,int val,int *count)
{
	NODE_t*curr_head=*head_ptr_ptr;
	if(*head_ptr_ptr==NULL)
	{
		*head_ptr_ptr=get_node(val);
		(*count)++;
	}
	else{
		while(curr_head->next!=NULL)
		{
			curr_head=curr_head->next;
		}
		curr_head->next=get_node(val);
		(*count)++;
	}
}

void delete_from_end(NODE_t**head_ptr_ptr,int *count){
	NODE_t*curr_head=*head_ptr_ptr;
	if(*head_ptr_ptr==NULL)
	{
		printf("Nothing to delete!!!!!\n");
		return;
	}
	else
	{
		while(curr_head->next->next != NULL)
		{
			curr_head=curr_head->next;
		}
		free(curr_head->next);
		curr_head->next=NULL;
		(*count)--;
	}


}
void delete_from_beg(NODE_t**head_ptr_ptr,int *count)
{

	if(*head_ptr_ptr==NULL)
	{
		printf("Nothing to delete!!!!!\n");
		return;
	}
	else
	{
		NODE_t*temp_node=*head_ptr_ptr;
		*head_ptr_ptr=(*head_ptr_ptr)->next;
		free(temp_node);
		(*count)--;

	}
}
void delete_from_pos(NODE_t**head_ptr_ptr,int pos,int *count){
	if(pos==0)
	{
		delete_from_beg(head_ptr_ptr, count);
	}
	else if(pos >= *count)
	{
		delete_from_end(head_ptr_ptr, count);
	}
	else
	{
		NODE_t*curr_head=*head_ptr_ptr;
		for(int i=1;i<pos;i++)
		{
			curr_head=curr_head->next;
		}
		NODE_t*temp_node=curr_head->next;
		curr_head->next=curr_head->next->next;
		free(temp_node);
		(*count)--;
	}
}



































