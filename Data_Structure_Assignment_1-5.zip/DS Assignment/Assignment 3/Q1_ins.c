
#include <stdio.h>
#include <stdlib.h>

int main()
{

    int size,z,temp;
    printf("enter the size of an array\n");
    scanf("%d",&size);
    int arr[size];
    printf("enter the element of an array\n");
    for(int i=0;i<size;i++)
    {
      scanf("%d",&arr[i]);
    }
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");

    for(int i=1;i<size;i++)
    {
        temp=arr[i];
        z=i-1;
        while(arr[z]>temp && z!=-1)
        {
            arr[z+1]=arr[z];
            z--;
        }
        arr[z+1]=temp;
    }
    for(int i=0;i<size;i++)
    {

      printf("%d\t",arr[i]);
    }
    printf("\n");
}
