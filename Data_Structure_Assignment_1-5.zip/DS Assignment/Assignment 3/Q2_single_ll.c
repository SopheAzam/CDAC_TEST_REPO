
#include <stdio.h>
#include <stdlib.h>

struct node{
	    int data;
	    struct node *next;
};

void insert_end(struct node **,int);
void display(struct node *);
void big_start(struct node **,int);
void odd_display(struct node *);
void delete_beg(struct node **);
void delete_end(struct node **);
int count(struct node *);
void insert_middle(struct node **,int,int);
void delete_middle(struct node **,int);
void reverse_display(struct node *);
void free_node(struct node *);
void reverse_list(struct node **);
void sorted_list(struct node *);
void delete_ele(struct node **,int);
int main()
{
	    int ele,choice,pos,ele1;
	    struct node *head=NULL;
	    while(1)
	    {
	        printf("***********************\n");
	        printf("1 for insert_end\n");
	        printf("2 for display\n");
	        printf("3 for big_start\n");
	        printf("4 for print odd no in link\n");
	        printf("5 for delete at big\n");
	        printf("6 for count the node in link\n");
	        printf("7 for delete from end\n");
	        printf("8 for insert at middle\n");
	        printf("9 for delete at position\n");
	        printf("10 for reverse display\n");
	        printf("11 for free all the node\n");
	        printf("12 for reverse list\n");
	        printf("13 for sorted list\n");
	        printf("14 for delete the element\n");
	        printf("15 for exit\n");
	        printf("default for try more\n");
	        printf("*******************************\n");

	        printf("enter the choice\n");
	        scanf("%d",&choice);

	        switch(choice)
	        {
	            case 1: printf("enter the value of element\n");
	                    scanf("%d",&ele);
	                    insert_end(&head,ele);
	                    break;
	            case 2:display(head);
	                   break;
	            case 3:printf("enter the element\n");
	                   scanf("%d",&ele);
	                   big_start(&head,ele);
	                   break;
	            case 4:odd_display(head);
	                   break;
	            case 5: delete_beg(&head);
	                    break;
	            case 6:count(head);
	            	   printf("count=%d\n",count(head));
	            	   break;
	            case 7:delete_end(&head);
	            	   display(head);
			           break;
	            case 8:printf("enter the value of element\n");
	                   scanf("%d",&ele);
	                   printf("enter the position at which node is connected\n");
	                   scanf("%d",&pos);
	                   insert_middle(&head,ele,pos);
	                   break;
	            case 9:printf("enter the position at which node is connected\n");
	                   scanf("%d",&pos);
	                   delete_middle(&head,pos);
	                   break;
	            case 10:reverse_display(head);
	                    break;
	            case 11:free_node(head);
	                    break;
	            case 12:reverse_list(&head);
	                    break;
	            case 13:sorted_list(head);
	                    break;
	            case 14:printf("enter the element\n");
	                    scanf("%d",&ele1);
	                    delete_ele(&head,ele1);
	                    break;
	            case  15:exit(0);
	                     break;
	            default:printf("try one more time\n");
	                    break;
	        }
	    }
	    return 0;
}
void insert_end(struct node **p,int ele)
{
	    struct node *temp,*t;
	    t=*p;
	    temp=(struct node *)malloc(sizeof(struct node));
	    temp->data=ele;
	    temp->next=NULL;
	    if(*p==NULL)
	    {
	        *p=temp;
	    }
	    else
	    {
	        while(t->next!=NULL)
	        {
	            t=t->next;
	         }
		t->next=temp;
	    }

}
void display(struct node *q)
{
	    while(q!=NULL)
	    {
	        printf("=%d\t",q->data);
	        q=q->next;
	    }
	      printf("\n");
}
/*
 int rec_display(struct node *q)
 {
    while(q!=NULL)
    {
       printf(">>%d\t",q->data);
       rec_display(q->next);
     }
  }

 */
void big_start(struct node **p,int ele)
{
	    struct node *temp;
	    temp=(struct node *)malloc(sizeof(struct node));
	    temp->data=ele;
	    temp->next=NULL;
	    if(*p==NULL)
	    {
	    *p=temp;
	    }
	    else
	    {
	        temp->next=*p;
	        *p=temp;
	    }
}
void odd_display(struct node *k)
{
	    while(k!= NULL)
	    {
	        printf(">>%d\t",k->data);
	        k=k->next->next;
	    }
}
	/*void delete_end(struct node **p)
	{
		struct node *temp;
		temp=*p;
		while(temp->next->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next=NULL;
		free(temp->next);
	}*/
void delete_beg(struct node **p)
{
	   struct node *t1;
	   t1=*p;
	   if(*p==NULL)
	   printf("no nodes\n");
	   else
	   {
	     *p=t1->next;
	     free(t1);
	   }
 }
int count(struct node *q)
{
		int count=0;
		while(q!=NULL)
		{
			q=q->next;
			count++;
		}
		return count;
}
void delete_end(struct node **p)
{
	    struct node *t1,*t2;
	    t1=*p;
	    t2=NULL;
	    if(*p==NULL)
	    printf("no nodes are aviliable\n");
	    else{
	        while(t1->next!=NULL)
	        {
	            t2=t1;
	            t1=t1->next;
	        }
	        t2->next=NULL;
	        free(t1);
	    }
	    display(*p);
}
void insert_middle(struct node **p,int ele,int pos)
{
	    struct node *temp,*t;
	    t=*p;
	    int i=1;
	    temp=(struct node *)malloc(sizeof(struct node));
	    temp->data=ele;
	    temp->next=NULL;
	    if(pos==1)
	    {
	        big_start(p,ele);
	    }
	    else{
	    while(i<pos-1)
	    {
	        t=t->next;
	        i++;
	    }
	    temp->next=t->next;
	    t->next=temp;
	    }
	    display(*p);
}
void delete_middle(struct node **p,int pos)
{
	    struct node *t1,*t2;
	    int i=1;
	    t1=*p;
	    t2=NULL;
	    if(pos==1)
	    {
	        delete_beg(p);
	    }
	    else{
	        while(i<pos)
	        {
	            t2=t1;
	            t1=t1->next;
	            i++;
	        }
	        t2->next=t1->next;
	        free(t1);
	    }
	    display(*p);
}

void reverse_display(struct node *p)
{
	if(p!=NULL)
	{
		reverse_display(p->next);
		printf("%d>>\t",p->data);
	}
}

void free_node(struct node *p)
{
	struct node *t;
	t=p;
	while(t!=NULL)
	{
		t=t->next;
		free(p);
		p=t;
	}
	if(p==NULL)
	printf("all nodes are removed\n");
}
void reverse_list(struct node **p)
{
	struct node *t1,*t2,*t3;
	t1=*p;
	t2=NULL;
	t3=NULL;
	while(t1!=NULL)
	{
		t3=t2;
		t2=t1;
		t1=t1->next;
		t2->next=t3;
	}
	*p=t2;
	display(*p);
}
void sorted_list(struct node *p)
{
	struct node *t;
	t=p;
	while(p->next!=NULL)
	{
		t=p->next;
		while(t!=NULL)
		{
			if(p->data > t->data)
			{
				int temp=p->data;
				p->data=t->data;
				t->data=temp;
			}
			t=t->next;
		}
		p=p->next;
	}
}
void delete_ele(struct node **p,int ele1)
{
	struct node *t,*k;
	t=*p;
	k=NULL;
	if(t->data==ele1)
	{
		*p=t->next;
		free(t);
	}
	else
	{
		while(t!=NULL && t->data!=ele1)
		{
			k=t;
			t=t->next;
		}
		k->next=t->next;
				free(t);
	}
}
















