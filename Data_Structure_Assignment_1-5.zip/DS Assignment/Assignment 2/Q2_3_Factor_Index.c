
#include <stdio.h>
#include <stdlib.h>

int value(int *,int ,int);
int main()
{
    int num,pos,index=0;
    int arr[10];
    printf("enter the number\n");
    scanf("%d",&num);

    for(int i=1;i<=num;i++)
    {
        if(num%i==0)
        {
            arr[index]=i;
            index++;
        }

    }

    for(int i=0;i<index;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");

    printf("Enter value of position\n");
    scanf("%d",&pos);

    num=value(arr,pos,index);
    printf("value = %d\n",num);
}

int value(int *arr,int pos,int index)
{
    if(pos > index )
    {
        return 0;
    }
    else{
        return arr[pos-1];
    }

}
