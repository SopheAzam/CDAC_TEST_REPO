
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int arr[5];
    int size;
    printf("enter the size of the array\n");
    scanf("%d",&size);
    printf("enter teh element of the array\n");
    for(int i=0;i<size;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<size;i++)
    {
        printf("%d\t",arr[i]);
    }
    printf("\n");

    int flag=0;
    for(int i=0;i<size;i++)
    {
       for(int j=0;j<size;j++)
        {
            if(i!=j)
            {
                if(arr[j]!=-1)
                {
                    if(arr[i]==arr[j])
                    {
                        flag=1;
                        printf("element=%d\t and index=%d\n",arr[i],i);
                    }

                }
            }
        }
    }
    if(flag==0)
    printf("no duplicate found\n");
    return 0;
}
