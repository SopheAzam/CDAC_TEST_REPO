
#include <stdio.h>
#include <stdlib.h>
void search(int,int [],int);
void search_recur(int,int [],int);
void display(int,int []);
void display_recur(int,int []);
void reverse(int,int []);
void reverse_recur(int,int []);

int main(void) {
	int size,choice,ele;
	printf("enter the size of an array\n");
	scanf("%d",&size);
	int arr[size];
	printf("enter the element\n");
	for(int i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}

	while(1)
	{
		printf("****************************\n");
		printf("1 for search the element\n");
		printf("2 for search the element by recursion\n");
		printf("3 for display the element\n");
		printf("4 for display the element by recursion\n");
		printf("5 for reverse order print the element\n");
		printf("6 for reverse order print element by recursion\n");
		printf("***************************************\n");
		printf("enter the choice\n");
		scanf("%d",&choice);
		switch(choice)
		{
				case 1:printf("enter the element\n");
				       scanf("%d",&ele);
					   search(size,arr,ele);
				       break;
				case 2:printf("enter the element\n");
			           scanf("%d",&ele);
				       search_recur(size,arr,ele);
				       break;
				case 3:display(size,arr);
				       printf("\n");
					   break;
				case 4:display_recur(size,arr);
				       printf("\n");
					   break;
				case 5:reverse(size,arr);
				       printf("\n");
					   break;
				case 6:reverse_recur(size,arr);
				       printf("\n");
					   break;
				case 7:exit(0);
				       break;
				default:printf("try again\n");
				        break;
		}
	}
	return 0;
}

void search(int size,int arr[size],int ele)
{
	int flag=0;
	for(int i=0;i<size;i++)
	{
		if(arr[i]==ele)
		{
			flag=1;
		    printf("index=%d\n",i);
		}
	}
    if(flag==1)
    printf("element=%d\n",ele);
    else
	printf("element not found in array\n");
}
void search_recur(int size,int arr[size],int ele)
{
	 static int i=0;
	if(arr[i]==ele)
	{
		printf("element=%d\tindex=%d\n",arr[i],i);
		return;
	}
	i++;
    search_recur(size,arr,ele);

}

void display(int size,int arr[size])
{
	for(int i=0;i<size;i++)
	{
		printf("%d\t",arr[i]);
	}
	printf("\n");
}
void reverse(int size,int arr[size])
{
	for(int i=size-1;i>=0;i--)
	{
		printf("%d\t",arr[i]);
	}
	printf("\n");
}
void display_recur(int size,int arr[size])
{
	   static int i=0;
	   if(i<size)
	   {
		     printf("%d\t",arr[i]);
		     i++;
	         display_recur(size,arr);
	   }

}
void reverse_recur(int size,int arr[size])
{
   --size;
   if(size>=0)
   {
	   printf("%d\t",arr[size]);
	   reverse_recur(size,arr);
   }

}




