
#include <stdio.h>
#include <stdlib.h>
int bin_search(int,int [],int ,int ,int);
int recursion_bin(int,int [],int ,int ,int);

int main(void) {
    int size,start,end,x;
    printf("enter the size of array\n");
    scanf("%d",&size);
    int arr[size];
    /*printf("enter the starting no of array\n");
    scanf("%d",&start);
    printf("enter the ending no of array\n");
    scanf("%d",&end);
    printf("enter the element find in an array\n");
    scanf("%d",&x);*/

    printf("enter the element of array from start to end\n");
    for(int i=0;i<size;i++)
    {
    	scanf("%d",&arr[i]);
    }
    for(int i=0;i<size;i++)
    {
       printf("%d\t",arr[i]);
    }
     printf("\n");
     start=0;
     end=size;
     printf("enter the element find in an array\n");
     scanf("%d",&x);

    int t=bin_search(size,arr,start,end,x);
    printf("index no for without recursion is=%d\n",t);

    int z=recursion_bin(size,arr,start,end,x);
    printf("index no with recursion is=%d\n",z);

    return EXIT_SUCCESS;
}
int bin_search(int size,int p[size],int start ,int end ,int x)
{
	while(start<=end)
	{
		int mid=start+(end-start)/2;
		if(p[mid]==x)
		return mid;

		if(p[mid]<x)
		{
			start=mid+1;
		}
		else
		{
			end=mid-1;
		}
	}
	return -1;
}

int recursion_bin(int size,int p[size],int start,int end,int x)
{
	if(start<=end)
	{
		int mid=start+(end-start)/2;
		if(p[mid]==x)
			return mid;
		if(p[mid]>x)
			return recursion_bin(size,p,start,mid-1,x);
		if(p[mid]<x)
			return recursion_bin(size,p,mid+1,end,x);
	}
	return -1;
}


































