
#include <stdio.h>
#include <stdlib.h>
#include<string.h>

struct gyro
{
	int x;
	int y;
	int z;
};

struct node
{
	struct gyro data;
	struct node *next;
};

struct queue
{
	struct node *front;
	struct node *rear;
	int count;
};

void enqueue(struct queue *,struct gyro);
struct gyro dequeue(struct queue * );
void display(struct queue *);
int peep(struct queue *);

int main(void) {

	int choice,x,y,z,w;
	struct queue q1;
	struct gyro data;
	q1.front=NULL;
	q1.rear=NULL;
	q1.count=0;

	while(1)
	{
		printf("************************\n");
		printf("1 for enqueue the element\n");
		printf("2 for dequeue the element\n");
		printf("3 for display the element\n");
		printf("4 for peep operation\n");
		printf("****************************\n");
		printf("enter the choice\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: printf("enter the value of x\n");
					scanf("%d",&data.x);
					printf("enter the value of y\n");
					scanf("%d",&data.y);
					printf("enter the value of z\n");
					scanf("%d",&data.z);
					enqueue(&q1,data);
					break;
			case 2:dequeue(&q1);
			        break;
			case 3:display(&q1);
			       break;
			case 4:w=peep(&q1);
			       printf("%d\n",w);
			       break;
			case 5:exit(0);
			       break;
			default:printf("try again\n");
			        break;
		}
	}
	return 0;
}

void enqueue(struct queue *p,struct gyro val)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	if(p->front==NULL && p->rear==NULL)
	{
		p->front=temp;
		p->rear=temp;
		p->count++;


	}
	p->rear->next=temp;
	p->rear=temp;
	p->count++;
}

struct gyro dequeue(struct queue *p)
{
	struct gyro ret;
	if(p->count==0)
	{
		printf("no nodes are connected\n");
	}
	else if(p->count==1)
		{
		   ret=p->front->data;
		   free(p->front);
		   p->front=NULL;
		   p->rear=NULL;
		   p->count--;
		}
	else{
		 ret=p->front->data;
	    struct node *temp=p->front;
	    p->front=p->front->next;
	    free(temp);
	    p->count--;
	}
	return ret;

}

void display(struct queue *p)
{
	//struct node*last;
	//last=p;
	if(p->front==NULL && p->rear==NULL)
	{
		printf("no node are connected\n");
	}
	while(p->front!=NULL)
	{
		printf("%d\t",p->front->data.x);
		printf("%d\t",p->front->data.y);
		printf("%d\n",p->front->data.z);
		p->front=p->front->next;
	}
}

int peep(struct queue *p)
{

	if(p->front==NULL && p->rear==NULL)
		{
			printf("no node are connected\n");
		}
	return p->front->data.x;
}


