
#include <stdio.h>
#include <stdlib.h>

typedef struct queue{
	int front;
	int rear;
	int *arr;
    int size;
}queue_t;

queue_t*createqueue(int size);
void insert_element(queue_t*,int val);
int delete_element(queue_t* queue);

int main(void) {
	int size,choice,val;
	printf("Enter size of queue : ");
	scanf("%d",&size);

	queue_t* queue1 = createqueue(size);

	while(1)
	{
		printf("0 - display\n");
		printf("1 - insert data in queue\n");
		printf("2 - remove data from queue\n");
		scanf("%d",&choice);
		switch(choice)
		{
		case 0:
				display(queue1);
				break;
		case 1:
                printf("Enter element to insert : ");
                scanf("%d",&val);
				insert_element(queue1,val);
				break;
		case 2:
				printf("%d deleted!!!\n",delete_element(queue1));
				break;
		case 3:
				exit(0);
		default:
				printf("Invalid Input!!!!!!1\n");
		}

	}
	return EXIT_SUCCESS;
}

void insert_element(queue_t* queue,int val)
{
    if(queue->rear==0)
    {
        
        queue->arr[0]=val;
        queue->rear++;
    }
    else if(queue->rear < queue->size )
    {
        int i=queue->rear;
        while(i > 0 && queue->arr[(i/2)] < val)
        {
            //campare with parent
                
                queue->arr[i] = queue->arr[(i/2)];
                i=(i/2);
        }
        queue->arr[i]=val;
        queue->rear++;
    }
    else
    {
        printf("queue is full!!!!!!\n");
    }
}

void display(queue_t*queue)
{
    for(int i=0;i<queue->rear;i++)
    {
        printf("%d\t",queue->arr[i]);
    }
    printf("\n");
}

int delete_element(queue_t* queue)
{
    if(queue->rear==0)
    {
        printf("Nothing to delete!!!!\n");
        return -1;
    }
    int temp=queue->arr[0];
        queue->arr[0] = queue->arr[queue->rear-1];

        int parent_index=0,child_index=2*parent_index+1;

        while(child_index < queue->size && queue->arr[parent_index] < queue->arr[child_index])
        {
            if(queue->arr[child_index] < queue->arr[child_index+1])
            {
                child_index=child_index+1;
            }
            if(queue->arr[parent_index] < queue->arr[child_index])
            {
                int temp=queue->arr[parent_index];
                queue->arr[parent_index]=queue->arr[child_index];
                queue->arr[child_index]=temp;

                parent_index=child_index;
                child_index=2*child_index+1;
            }
        }
        queue->rear--;
        return temp;
}

queue_t*createqueue(int size)
{
	queue_t*temp=(queue_t*)malloc(sizeof(queue_t));
	temp->front=-1;
	temp->rear=0;
    temp->size=size;
	temp->arr=(int*)malloc(sizeof(int)*size);
	return temp;
}

