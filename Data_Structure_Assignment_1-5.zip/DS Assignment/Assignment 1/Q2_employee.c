
#include<stdio.h>
struct empolyee
{
	int empid;
	char em_name[20];
	int salary;
	int doj;
};
int main()
{
	struct empolyee arr[5];
	int sum=0,avg,max,min,temp1,temp2;
	for(int i=0;i<5;i++)
	{
	   printf("\nenter the details of employee:%d\n",i+1);
	   printf("enter the employe id,name,salary,doj\n");
	   scanf("%d %s %d %d",&arr[i].empid,arr[i].em_name,&arr[i].salary,&arr[i].doj);
	   printf("\n");
	   printf("empid=%d\nem_name=%s\nsalary=%d\ndoj=%d\n",arr[i].empid,arr[i].em_name,arr[i].salary,arr[i].doj);
	}

	for(int i=0;i<5;i++)
	{
		sum=sum+arr[i].salary;
	}
	printf("\n");
	printf("sum of salary=%d\n",sum);
	avg=sum/5;
	printf("avg of salary=%d\n",avg);

	max=arr[0].salary;
	for(int i=0;i<5;i++)
	{
	  if(arr[i].salary>max)
	  max=arr[i].salary;
	 }
	printf("maximum of salary=%d\n",max);

	min=arr[0].salary;
	for(int i=0;i<5;i++)
	{
	  if(arr[i].salary<min)
	  min=arr[i].salary;
	 }
	printf("minimum of salary=%d\n",min);

	temp1=arr[0].doj;

	for(int i=0;i<5;i++)
	{
	  if(arr[i].doj<temp1)
	  temp1=arr[i].doj;
	 }
	printf("\n");
	printf("maximum service in term of doj is=%d\n",temp1);

	temp2=arr[0].doj;
	for(int i=0;i<5;i++)
	{
	  if(arr[i].doj>temp2)
	  temp2=arr[i].doj;
	 }
	printf("minimum service in term of doj is=%d\n",temp2);

	return 0;
}
