#include<stdio.h>
#include<stdlib.h>

typedef struct array_info{
    int *sarr;
    int col;
}array_t;


int main(){
    int row,col,size;
    printf("Enter size of array : ");
    scanf("%d",&size);
    
    //assign memoro
    int *arr_1D=(int*)malloc(sizeof(int)*size);
    //init arr
    for(int i=0;i<size;i++)
    {
        printf("Enter element of index %d : \n",i);
        scanf("%d",&arr_1D[i]);
    }

    printf("Printing 1D array \n");
    for(int i=0;i<size;i++)
    {   
        printf("%d\t",arr_1D[i]);
    }
    printf("\n");

    //2D array with fixed number of column
    printf("Array of fixed col length : ");
    printf("Enter number of rows : ");
    scanf("%d",&row);
    printf("Enter number of column : ");
    scanf("%d",&col);

    int(*arr_2D)[col]=(int (*)[col])malloc(sizeof(int)*row*col);
    //init 2D array
    printf("initialising 2D Array\n");
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            printf("Enter element of row %d col %d \n",row,col);
            scanf("%d",(*(arr_2D+i)+j));
        }
    }

    //printing array
     printf("Printing 2D array with fixed column \n");
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            printf("%d ",arr_2D[i][j]=i);
        }
        printf("\n");
    }
    printf("\n");

    //2D array with variable columns
    printf("Array of variable col length : ");
    printf("Enter number of rows : ");
    scanf("%d",&row);

    //row
    array_t *arr = (array_t*)malloc(sizeof(array_t)*row);

    //col
    for(int i=0;i<row;i++){
        
        printf("Enter size of col of row %d : ",i);
        scanf("%d",&col);
        
        arr[i].col=col;
        arr[i].sarr = (int *)malloc(sizeof(int)*col);
        
        for(int j=0;j<col;j++)
        {
            arr[i].sarr[j]=j+1;
        }
    }

    //print array with variable column

    printf("Printing 2D array with variable column \n");
    // printf("Enter row and col you want to print rowxcol\n");
    // scanf("%dx%d",&row,&col);

        for(int i=0;i<row;i++){
            for(int j=0;j<arr[i].col;j++){
                // printf("%d ",arr[i].sarr[j]);
                printf("*");
            }
        printf("\n");
        }
        printf("\n");
        
}
