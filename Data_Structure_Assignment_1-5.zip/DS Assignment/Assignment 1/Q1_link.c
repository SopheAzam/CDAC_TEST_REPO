
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void insert(int,int []);
void delete(int,int []);
void min(int,int []);
void max(int,int []);
void display(int,int []);
void reverse_display(int,int []);
void search(int,int []);
void count(int,int []);
void avg(int,int []);
void duplicate(int,int []);
void reverse_element(int,int []);

int main()
{
    int size,choice;
    printf("enter the size of an array\n");
    scanf("%d",&size);

    int arr[size];
    for(int i=0;i<size;i++)
    {
        arr[i]=i+1;
    }
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");

    while (1)
    {
       printf("********************************\n");
       printf("1 for insert the element in an index\n");
       printf("2 for delete the element in an index\n");
       printf("3 for minimum value in element\n");
       printf("4 for maximum value in element\n");
       printf("5 for display array element\n");
       printf("6 for reverse display of array element\n");
       printf("7 for search element in array\n");
       printf("8 for array element count\n");
       printf("9 for avg of all element\n");
       printf("10 for determine aaray contain any duplicates\n");
       printf("11 for reverse array element\n");
       printf("12 for exit\n");
       printf("default try again\n");
       printf("*******************************\n");

       printf("enter the value of choice\n");
       scanf("%d",&choice);

       switch(choice)
       {
           case 1: insert(size,arr);
                   break;
           case 2: delete(size,arr);
                   break;
           case 3: min(size,arr);
                   break;
           case 4: max(size,arr);
                   break;
           case 5: display(size,arr);
                   break;
           case 6: reverse_display(size,arr);
                   break;
           case 7: search(size,arr);
                   break;
           case 8: count(size,arr);
                   break;
           case 9: avg(size,arr);
                   break;
           case 10:duplicate(size,arr);
                   break;
           case 11:reverse_element(size,arr);
                   break;
           case 12:exit(0);
                   break;
           default:printf("try again\n");
                   break;
       }

    }
    return 0;
}
void insert(int size,int arr[size])
{
    int ele,index;
    printf("enter the element which we have insert\n");
    scanf("%d",&ele);
    printf("enter the index no which we have insert\n");
    scanf("%d",&index);

       if(arr[index]==-1)
       arr[index]=ele;
       else
       printf("array size is full\n");
}
void delete(int size,int arr[size])
{
    int index;
    printf("enter the index no u want to delete\n");
    scanf("%d",&index);
    arr[index]=-1;
    for(int i=0;i<size;i++)
    {
        printf("%d\t",arr[i]);
    }
}
void min(int size,int arr[size])
{
    int min=arr[0];
    for(int i=0;i<size;i++)
    {
        if(arr[i]<min)
           min=arr[i];
    }
    printf("minimum value=%d\n",min);
}
void max(int size,int arr[size])
{
    int max=arr[0];
    for(int i=0;i<size;i++)
    {
        if(arr[i]>max)
        max=arr[i];
    }
    printf("maximum value=%d\n",max);
}
void display(int size,int arr[size])
{
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");
}
void reverse_display(int size,int arr[size])
{
    for(int i=size-1;i>=0;i--)
    {
      printf("%d\t",arr[i]);
    }
    printf("\n");
}
void search(int size,int arr[size])
{
    int i,ele,flag=0;
    printf("enter the element in array which u have search\n");
    scanf("%d",&ele);
    for(i=0;i<size;i++)
    {
        if(arr[i]==ele)
         {
             flag=1;
             break;
         }
    }
    if(flag==1)
    printf("your index number=%d\n",i);
    else
    printf("worng element entered\n");
}
void count(int size,int arr[size])
{
    int count1=0;
    for(int i=0;i<size;i++)
    {
        if(arr[i]==-1)
        {
        }
        else
        count1++;
    }
    printf("count the no of element is=%d\n",count1);
}
void avg(int size,int arr[size])
{
        int sum=0,avg;
        for(int i=0;i<size;i++)
        {
            sum=sum+arr[i];
        }
        avg=sum/size;
        printf("avg of all element=%d\n",avg);
}
void duplicate(int size,int arr[size])
{
        int dub,z=0;
        printf("enter the element which having duplicate\n");
        scanf("%d",&dub);
        for(int i=0;i<size;i++)
        {
            if(arr[i]==dub)
            z++;
        }
        if(z==0)
        printf("element is outside the array\n");
        else if(z==1)
        printf("not duplicate issue\n");
        else
        printf("duplicate issue\n");
}
void reverse_element(int size,int arr[size])
{
    int ret;
   for(int i=0;i<size/2;i++)
   {
       int ret=arr[i];
           arr[i]=arr[size-1-i];
           arr[size-1-i]=ret;
   }
    for(int i=0;i<size;i++)
    {
      printf("%d\t",arr[i]);
    }

}
