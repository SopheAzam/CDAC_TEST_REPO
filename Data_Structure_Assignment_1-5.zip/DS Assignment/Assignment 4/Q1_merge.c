

#include <stdio.h>
#include <stdlib.h>
void partation(int,int[],int,int);
void mergesort(int,int [],int,int,int);

int main(void)
{
	int size;
	printf("enter the size of array\n");
	scanf("%d",&size);
	int arr[size];
	printf("enter the element\n");
	for(int i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
	partation(size,arr,0,size-1);
	for(int i=0;i<size;i++)
	{
		printf("%d\t",arr[i]);
	}

	return EXIT_SUCCESS;
}
void partation(int size,int arr[size],int first,int last)
{
	if(first<last)
	{
		int mid=(first+last)/2;
		partation(size,arr,first,mid);
		partation(size,arr,mid+1,last);
	    mergesort(size,arr,first,mid,last);
	}
}
void mergesort(int size,int arr[size],int first,int mid,int last)
{
    int b[100];
	int i=first;
	int j=mid+1;
	int k=first;

	while(i<=mid && j<=last)
	{
		if(arr[i]<=arr[j])
		{
			b[k]=arr[i];
		    i++;
		    k++;
		}
		else{
		b[k]=arr[j];
		k++;
		j++;
		}
	}
	if(i>mid)
	{
		while(j<=last)
		{
			b[k]=arr[j];
			k++;
			j++;
		}
	}
		else{
			while(i<=mid)
			{
				b[k]=arr[i];
				k++;
				i++;
			}
		}
	for (k=first;k<=last;k++)
	{
		arr[k]=b[k];
	}

}









