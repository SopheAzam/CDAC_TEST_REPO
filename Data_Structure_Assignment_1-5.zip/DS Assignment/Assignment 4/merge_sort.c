#include<stdio.h>


int main()
{
    int i,size;
    printf("enter size of array");
    scanf("%d",&size);
    int arr1[size];
    printf("enter elements of array");
    for(i=0;i<size;i++)
    {
        scanf("%d",&arr1[i]);
    }
    int arr2[size];
    printf("enter elements of array");
    for(i=0;i<size;i++)
    {
        scanf("%d",&arr2[i]);
    }
    int arr3[20];
    merge_array(arr1,arr2,arr3,size);
    return 0;
}

void merge_array(int *arr1,int *arr2,int * arr3,int size)
{
    int i,j,k,min;
    for(i=0;i<size;i++)
    {
        for(j=0;j<size;j++)
        {
            if(*(arr1+i) < *(arr2+j))
            {
                min=arr2[j];
            }
            else
            {
                min=arr1[i];
            }
        }
    }
}