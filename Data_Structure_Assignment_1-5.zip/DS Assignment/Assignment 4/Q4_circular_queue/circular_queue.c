
#include"circular_header.h"
int main()
{
	int ele,choice;
	struct queue s1;
	s1.front=-1;
	s1.rear=-1;
	for(int i=0;i<SIZE;i++)
	{
		s1.arr[i]=-99;
	}
	while(1)
	{
		printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
		printf("1 for enqueue the element\n");
		printf("2 for dequeue the element\n");
		printf("3 for peep the element\n");
		printf("4 for display the element\n");
		printf("5 for exit\n");
		printf("default:try again\n");
		printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");

		printf("enter the choice\n");
		scanf("%d",&choice);

		switch(choice)
		{
			case 1:printf("enter the value of element\n");
			       scanf("%d",&ele);
			       enqueue(&s1,ele);
			       break;
			case 2:printf("delete element=%d\n",dequeue(&s1));
			       break;
			case 3:printf("current position=%d\n",peep(s1));
			       break;
			case 4:display(s1);
			       break;
			case 5:exit(0);
			       break;
			default:printf("try again\n");
			        break;
		}
	}
	return 0;
}

