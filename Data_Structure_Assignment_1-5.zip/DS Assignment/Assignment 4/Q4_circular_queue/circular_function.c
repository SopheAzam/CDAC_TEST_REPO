

#include"circular_header.h"
void enqueue(struct queue *s,int ele)
{
	if((s->front==0 && s->rear==SIZE-1) || (s->rear+1==s->front))
	{
		printf("queue is full\n");
	}
	if(s->rear==SIZE-1)
	{
		s->rear=0;
	}
	else
	{
		s->rear++;
	}
		s->arr[s->rear]=ele;

	if(s->front==-1)
		s->front=0;
}
int dequeue(struct queue *s)
{
	if(s->front==-1)
	printf("queue is empty\n");

	int item=s->arr[s->front];
	s->arr[s->front]=-99;

	if(s->front==s->rear)
		s->front=s->rear=-1;
	else{
		if(s->front==SIZE-1)
			s->front=0;
		else
		s->front++;
	}
	return item;
}
int peep(struct queue s)
{

	if(s.front==-1)
	{
		printf("circular queue is empty\n");
	}
	int item=s.arr[s.front];
	return item;
}
void display(struct queue s)
{
	if(s.front==-1)
	{
		printf("circular queue is empty\n");
	}
	for(int i=0;i<SIZE;i++)
	{
	   printf("%d\t",s.arr[i]);
	 }
	printf("\n");
}
