
#ifndef HEADER_H_
#define HEADER_H_
#include<stdio.h>
#include<stdlib.h>
#define SIZE 5

struct queue
{
	int arr[SIZE];
	int front;
	int rear;
};
void enqueue(struct queue *,int);
int dequeue(struct queue *);
int peep(struct queue);
void display(struct queue);



#endif /* HEADER_H_ */
