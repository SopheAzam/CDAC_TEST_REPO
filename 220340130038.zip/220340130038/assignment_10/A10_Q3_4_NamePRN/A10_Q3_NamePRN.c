#include<stdio.h>

int main(){
	FILE *fp;
	char ch;

	fp=fopen("mydata.txt","w");
	
	printf("Enter name and PRN\n");
	while((ch=getc(stdin))!=EOF){
		putc(ch,fp);
	}
	//fp is at last so need to close file 
	fclose(fp);
	
	//fp is opening in "r" mode
	fp=fopen("mydata.txt","r");
	printf("Printing data\n");
	while((ch=getc(fp))!=EOF){
		printf("%c",ch);
	}


}
