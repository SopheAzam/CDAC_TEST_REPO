#include<stdio.h>

int main(){
	FILE *fp;
	int count=0;
	char ch;
	fp=fopen("read.txt","r");
	//
	//reading characters
	while((ch=getc(fp))!=EOF){
		if(ch!=' ' && ch!='\n')
			count++;
	}
	printf("total characters are %d\n",count);
}
