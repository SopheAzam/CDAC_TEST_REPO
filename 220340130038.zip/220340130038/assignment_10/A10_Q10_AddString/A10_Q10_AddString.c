#include<stdio.h>
#define MAX_SIZE 20


int main(){
	FILE *fp;
	char arr[MAX_SIZE];

	fp=fopen("hello.txt","r");

	//read 1st 7 char from file	//we can use loop and read char by char also
	fgets(arr,8,fp);		//Need to take one extra char because last char '\0'
	printf("%s\n",arr);	

	//close file to reset pointer
	fclose(fp);
	fp=fopen("hello.txt","r");
	//set curser at 8th pos
	fseek(fp,8,SEEK_SET);
	fgets(arr,5,fp);	//taking next 5 char
	printf("%s\n",arr);	

	//close file to reset pointer
	fclose(fp);
	//try to print in reverse using fseek
	fp=fopen("hello.txt","r");
	//set pointer fp at end
	fseek(fp,0,SEEK_END);
	//get location of fp
	int Loc_fp=ftell(fp)-1;		//-1 for last element is EOF
	printf("location of fp =%d\n",Loc_fp);	
	char ch;
	while(Loc_fp!=0){
		fseek(fp,--Loc_fp,SEEK_SET);
		ch=fgetc(fp);
		printf("%c",ch);	
	}
	printf("\n");
}
