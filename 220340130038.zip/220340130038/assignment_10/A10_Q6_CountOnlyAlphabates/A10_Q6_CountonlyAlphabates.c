#include<stdio.h>

int main(){
	FILE *fp;
	int count=0;
	char ch;
	fp=fopen("read.txt","r");
	//
	//reading characters
	while((ch=getc(fp))!=EOF){
		if(ch>='a' && ch<='z')
			count++;
	}
	printf("total alphabates are %d\n",count);
}
