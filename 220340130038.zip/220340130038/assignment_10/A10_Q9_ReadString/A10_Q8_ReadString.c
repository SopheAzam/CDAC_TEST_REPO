#include<stdio.h>
#define MAX_SIZE 20


int main(){
	FILE *fp;
	char arr[MAX_SIZE];

	printf("enter string\n");
	fgets(arr,20,stdin);
//	printf("%s",arr);	

	fp=fopen("test.txt","w");
	fprintf(fp,"%s\n",arr);	
	fclose(fp);
	
	fp=fopen("test.txt","r");
	printf("\nprinting file\n");
	char ch;
	//We are printing file
	while((ch=fgetc(fp))!='\n'){
		printf("%c",ch);
	}
	printf("\n");

	/*if we want to copy file into char arr[]
	 *
	 * fgets(arr,20,fp)
	 *
	 */
}
