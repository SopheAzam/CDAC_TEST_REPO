#include<stdio.h>


int main(){
	FILE *fp;
	char ch;
	fp=fopen("mytext.txt","r+");//r+ wil not create file so segmentation fault	
	while((ch=fgetc(fp))!='\n'){
		putc(ch,stdout);
		//printf("%c",ch);
	}
	printf("\n");

}
