#include<stdio.h>



int main(){
	FILE *fp;
	char ch;
	
	fp=fopen("mytext.txt","r");
	
	while((ch=fgetc(fp))!='\n'){
		putc(ch,stdout);
		//printf("%c",ch);
	}
	printf("\n");
	fclose(fp);

}
