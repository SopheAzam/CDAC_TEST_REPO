#include<stdio.h>
#define MAX_SIZE 20

int main(){

	FILE *fp;
	char arr[MAX_SIZE]="abcdefg";

	//Reading file in "w" mode
	fp=fopen("test.txt","w");	
	fgets(arr,MAX_SIZE,fp);
	perror("Write");
	fclose(fp);
	

	//Writing file in "r" mode
	fp=fopen("test.txt","r");
	fputs(arr,fp);
	perror("Read");
	fclose(fp);
	
	//Writing file in "w" mode
	fp=fopen("test.txt","w");
	fputs(arr,fp);
	fflush(stdout);

	perror("WRITE");
	fclose(fp);
	
	/*
	 * this time perror will give same error as above 
	 * because perror take last entry fro strerror
	 *
	 */
}
