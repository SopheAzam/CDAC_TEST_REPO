//refer notebook notes if 06/04/2022

#include<stdio.h>

int main(){
	
	FILE *fp;
	char ch;

	fp=fopen("q2.c","w");
	printf("enter program\n");
	
	while((ch=getc(stdin))!=EOF){
		//scanf("%c",&ch);
		putc(ch,fp);
	}
	fclose(fp);
	
	//opening file with r+
	fp=fopen("q2.c","r+");
	while((ch=getc(fp))!=EOF){
		putc(ch,stdout);
	}
}

//refer notebook notes of 06/04/2022
