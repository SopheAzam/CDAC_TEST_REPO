/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: Using Sprintf
*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>


int main()
{
    char *str1 = "Ashish";
    char str2[10] = "Jog";
    char buffer[50]={0};
    char buffer2[50]={0};
    sprintf(buffer,"%s%s",str1,str2);
    printf("%s\n",buffer);
    printf("%d\n",strlen(buffer));
    sprintf(buffer2,"%s",str1);
    printf("%s\n",buffer2);
    return 0;
}