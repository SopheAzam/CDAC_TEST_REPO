/*
 *Name :- Ashish Hemant Jog
 *Date :- 30/12/2022
 *Decription:- Implementation of the string functions   
 */

#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>

#define DEBUG_STRING_ENGINES

// Function Prototypes
int string_length_finder_engine(const char*);
char* string_copying_engine(char*, const char*,int size);
char* string_joiner_engine(const char*,const char*);
int string_compare_engine(const char*, const char*);
void string_reverse_engine(const char*);
void string_first_occurrence_finder_engine(const char*,char);
void string_last_occurrence_finder_engine(const char*, char);
void string_count_occurrences_of_a_char(const char*, char);	
void string_find_substring_in_given_string(const char*, const char*);
void string_substring_start_end_finder(const char*, const char*);
void string_display_engine(const char*);

int main()
{
       char usrStr[100],usrStr2[100]; /*we cannot use char* from user as it will be violation that is on runtime chaging in pool!*/
       char* retStr;
	   int retV=0;
       printf("Hello!, Enter the string 1\n");
       scanf("%s",usrStr);
		printf("Hello!, Enter the string 2\n");
       scanf("%s",usrStr2);
     //  string_display_engine(usrStr);
    //   string_length_finder_engine(usrStr);
      // printf("%ld\n",strlen(usrStr));
  //     retStr = string_copying_engine(usrStr2,usrStr,string_length_finder_engine(usrStr));
 		 retV = string_compare_engine(usrStr,usrStr2);
       printf("Retval = %d\n", retV);
}
// 1. String Length Finder 
int string_length_finder_engine(const char* str)
{
	int char_counter = 0;
	while(str[char_counter]!='\0')
	{
	  char_counter++;		 
	}
	
#ifdef DEBUG_STRING_ENGINES
        printf("Inside Function : Length of a string is %d\n",char_counter);
#endif
	return char_counter;
}

// 2. String Copy
char* string_copying_engine(char* dest, const char* src, int size)
{
	uint32_t char_counter=0;
	for(char_counter=0; char_counter<size;char_counter++)// (size && char_counter!='\0') ; char_counter++)
	{
	    dest[char_counter] = src[char_counter];
	}

#ifdef DEBUG_STRING_ENGINES	
	printf("Inside Function copy  \n");
//	printf("Destination : %s", dest);
//	printf("Source : %s", src);
	string_display_engine(dest);

#endif		
	return dest;
}

// 3. String Joiner / Strcat

char* string_joiner_engine(const char* str1,const char* str2){
		int fin_len = strlen(str1)+strlen(str2);
		printf("%d\n",strlen(str1));
		printf("%d\n",strlen(str2));
		printf("%d\n",fin_len);
		char* str_cat_res=0;
		char *heap_ch_ptr = (char*)malloc(sizeof(char)*fin_len);
		int i=0,j=0;
		for( i=0; i<strlen(str1); i++)
		{
			heap_ch_ptr[i] = str1[i];
		}
		for(j=0; j<strlen(str2); j++)
		{
			heap_ch_ptr[j+i] = str2[j];
		}
		printf("%s\n",heap_ch_ptr);
		return heap_ch_ptr;
}

// 4. String compare
int string_compare_engine(const char* str1, const char* str2)
{
	int i=0,match_count=0;
		if(strlen(str1)!=strlen(str1))
		{
			return 0;
		}
		else{
			for(i=0;str1[i]!='\0';i++)
			{
				if(str1[i]==str2[i])
				{
					match_count++;
				}
				else{
					match_count = 0;
				}
			}
			if(match_count == strlen(str1))
			{
				printf("Strings are equal!\n");
				return 1;
			}
		}
}


void string_display_engine(const char* str)
{
	printf("%s",str);
}



