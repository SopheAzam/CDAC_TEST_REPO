/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/

#include<stdio.h>
#include<stdint.h>
#include<string.h>

int a[20]={10};
int b[10]={0};

int main()
{
    int i = 0;
    for(i=0;i<sizeof(a);i++)a[i]=i;
    memcpy(b,a,sizeof(b));
    for(i=0;i<sizeof(b);i++)
    printf("%d = %d\n",i,b[i]);
    return 0;
}