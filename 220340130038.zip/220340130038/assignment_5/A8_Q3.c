/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description:  strncpy, strncat, strncmp, strcasecmp, strncasecmp, strchr, strrchr, strstr, strtok, sprintf, snprintf, sscanf
*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>

char str1[20];
char str2[20];


int main()
{
// 1. strncpy
    strcpy(str1,"Ashish");
    strcpy(str2,"Hemant");
    printf("%s\n",str1);
 //   strncpy(str1,str2,strlen(str2));
    printf("%s\n",str1); 

// 2. strncat     
  //  strncat(str1,str2,strlen(str2));
    printf("%s\n",str1); 

// 3. strncmp
  //  strncmp(str1,str2,5);    
    return 0;
// 4. strcasecmp 

// 5. strncasecmp,

// 6. strchr
    strcpy(str1,"XYZ.ABC");
    char ch = '.';
    char* ret = strchr(str1, ch);
    printf("%s\n",ret);

// 7.   
}