#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<assert.h>
char main_string[100]="MYASHISHISGOOD";
char sub_string[100]="MYASHISHISGOOD";
char temp_string[100];
int main()
{
	int i=0,j=0,cnt=0,match_cnt=0,k=0;
	printf("%d\n",(strlen(main_string)-strlen(sub_string)));
	assert(strlen(sub_string)<strlen(main_string)); // assertion to ensure the substring is always smaller or equal
	int oc = (strlen(main_string)-strlen(sub_string))+1;
	for(j=0;j<oc;j++)
	{
	
	for(i=0+j,k=0;i<strlen(sub_string)+j,k<strlen(sub_string);i++,k++)
	{
		temp_string[k] = main_string[i];
	}
	printf("%s\n",temp_string);
	for(i=0;i<strlen(sub_string);i++)
	{
	if(temp_string[i] == sub_string[i])
	{
		match_cnt++;
		printf("Matched %d!\n",match_cnt);
	}
	else{
		match_cnt=0;
	}
	}	
	if(match_cnt == strlen(sub_string))
	{
		match_cnt=0;
		printf("sub_string found!\n");
	}
}
	return 0;
}
