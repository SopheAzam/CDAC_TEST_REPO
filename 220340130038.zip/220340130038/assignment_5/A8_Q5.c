/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<math.h>

// Function Protos
int ascii2Integer(const char*);
char* integer2Ascii(int);

int main()
{
    int retInt = 0;
    char* str = "-167";
    retInt = ascii2Integer(str);
    printf("%d\n",retInt);
    integer2Ascii(123);
    return 0;
}

int ascii2Integer(const char* string){ // Add=>sign check
    int i = 0, integer = 0;
    int signFlag = 1;
    int stlen = strlen(string);
    stlen = stlen - 1;
    printf("Len = %d\n",stlen);
    if(string[i] == '-')
    {
        signFlag = -1;
        i++; // Go to the number
        stlen = stlen - 1; // Decrease as - is an extra character
    }
    while(string[i]!='\0')
    {   
        integer += pow(10,(stlen))*(string[i]-'0');
        stlen = stlen-1;
        i++;
    } 
    return signFlag*(integer);
}

char* integer2Ascii(int num){
    char string[100]={0};
    int rem=0, divd = 0, i=0;
    while(num>0){
        rem = num%10;
        num = num/10;
        string[i++]=48+rem;
        }
        printf("%s\n",string);
        
}

