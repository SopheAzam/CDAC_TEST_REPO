/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
char ipv4[20] = "192.168.1.124";

typedef union {
    uint32_t ipv4_32bit_address;
    struct IPV432BIT
    {
       uint8_t ipv4_first_field;
       uint8_t ipv4_second_field;
       uint8_t ipv4_third_field;
       uint8_t ipv4_fourth_field;
    }ipv4FieldStructPacket;
}ipv4bytepackUnpack;



int main()
{
    ipv4bytepackUnpack ipv4pckUnpck;
    char* token = strtok(ipv4, ".");
    int _8bitFields[4]={0},counter=0;
    while (token != NULL) {
        printf("%s\n", token);
        _8bitFields[counter]=atoi(token);
        counter++;
        token = strtok(NULL, ".");
    }
    for(counter=0;counter<4;counter++)printf("counter = %d\n",_8bitFields[counter]);
    
    ipv4pckUnpck.ipv4FieldStructPacket.ipv4_first_field  = _8bitFields[3];
    ipv4pckUnpck.ipv4FieldStructPacket.ipv4_second_field = _8bitFields[2];
    ipv4pckUnpck.ipv4FieldStructPacket.ipv4_third_field  = _8bitFields[1];
    ipv4pckUnpck.ipv4FieldStructPacket.ipv4_fourth_field = _8bitFields[0];

    printf("The 32-bit ipv4 address in the integer format is %x\n",ipv4pckUnpck.ipv4_32bit_address);

    return 0;
    
}