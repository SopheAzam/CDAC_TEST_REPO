/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: Implementing a generic swap function 
*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<assert.h>
#include<stdlib.h>

void generic_swap(void* first_member, void* second_member, size_t size);

int main()
{
    int a = 123, b = 312;
    float pi = 3.141592, e=2.71828;
    char str1[10]="ABC", str2[10]="XYZ"; // char* not working!?
    printf("Before Swap %d %d\n",a,b);
    generic_swap(&a,&b,sizeof(int));
    printf("After Swap %d %d\n",a,b);

    printf("Before Swap %f %f\n",pi,e);
    generic_swap(&pi,&e,sizeof(float));
    printf("After Swap %f %f\n",pi,e);

    printf("Before Swap %s %s\n",str1,str2);
    generic_swap(str1,str2,sizeof(str1));
    printf("After Swap %s %s\n",str1,str2);
   
    return 0;
}

void generic_swap(void* first_member, void* second_member, size_t size)
{
    void* temp_heap = malloc(size);
    assert(temp_heap != NULL);
    memcpy(temp_heap,first_member,size);
    memcpy(first_member,second_member,size);
    memcpy(second_member,temp_heap,size);
    free(temp_heap);
}