/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>



int main()
{
    
    return 0;
}