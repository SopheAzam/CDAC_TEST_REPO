/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: GIVEN MEMBER ADDRESS FIND THE BASE ADDRESS
*/
#include<stdio.h>
#include<stdint.h>
#include<stddef.h>

#define BASE_ADDRESS (&a9q2)
#define END_ADDRESS  (&a9q2+1)
#define OFFSETOF(TYPE, ELEMENT) ((size_t)&(((TYPE *)0)->ELEMENT))
typedef struct 
{
    int x;
    double y;
    float z;
    char ch;
}A9Q2_str;

int main()
{
    A9Q2_str a9q2;
    printf("%p\n",BASE_ADDRESS);   // Base Address 
    printf("%p\n",END_ADDRESS); // End Address 
    printf("%p\n",&a9q2.x);
    printf("%p\n",&a9q2.y);
    printf("%p\n",&a9q2.z);
    printf("%p\n",&a9q2.ch);
    printf("%d\n",(A9Q2_str*)END_ADDRESS-(A9Q2_str*)BASE_ADDRESS);
    printf("%d\n",(A9Q2_str*)(&a9q2+1)-(A9Q2_str*)(&a9q2));
    printf("%d\n",sizeof(a9q2));

    A9Q2_str *a9q2_ptr = (A9Q2_str*)NULL;

    printf("%p\n",a9q2_ptr);

    // printf("%d\n",OFFSETOF(A9Q2_str,x));
    // printf("%d\n",OFFSETOF(A9Q2_str,y));
    // printf("%d\n",OFFSETOF(A9Q2_str,z));
    // printf("%d\n",OFFSETOF(A9Q2_str,ch));

    printf("%d\n",offsetof(A9Q2_str,x));
    printf("%d\n",offsetof(A9Q2_str,y));
    printf("%d\n",offsetof(A9Q2_str,z));
    printf("%d\n",offsetof(A9Q2_str,ch));

    // Suppose address of y is known then 

    printf("2nd member address = %p\n",(A9Q2_str*)&(a9q2_ptr->y));
    printf("2nd member address = %p\n",&(a9q2_ptr));
    printf("2nd member address = %p\n",&(a9q2.y)-offsetof(A9Q2_str,y));

    return 0;
}