// Author: Ashish Hemant Jog
// Date  : 07/04/2022	 
// Description : TO CREATE A STUDENT AND EMPLOYEE STRUCTURE AND DO THE SAID OPERATIONS

// Includes
#include "Inc/A9_Q1.h"

EMPLOYEE_DATA_STRUCT emp_data_struct[TOTAL_EMPLOYEES];
int employee_gloabal_counter = 0;
FILE* fPtr=NULL;

int main()
{
	ui_dashboard();
	return 0;
}

void ui_dashboard()
{
	int infoType = 0;
	printf("-----------------------------------------------------\n");	
	printf(" Welcome to Employee Portal! \n");
	printf("-----------------------------------------------------\n");		
	printf("Press 1 To Enter The Personal Information\n");
	printf("Press 2 To Enter The Educational Information\n");	
	printf("Press 3 To Enter The Professional Information\n");
	scanf("%d",&infoType);
	printfWithFlush("Enter your full name as per Aadhar Card:");
	scanf("%[^\n]s",emp_data_struct.emp_per_inf.name);
	switch(infoType)
	{
		case EMPLOYEE_PERSONAL_INFO_:
				getEmployeePersonalInfo();
		break;

		case EMPLOYEE_EDUCATIONAL_INFO_:
				getEmployeeEducationalInfo();
		break;

		case EMPLOYEE_PROFESISONAL_INFO_:
				getEmployeeProfessionalInfo();
		break;

		default:
				printf("Enter the correct choice!\n");
				exit(0);
		break;
	}
}

void getEmployeePersonalInfo()
{
	printfWithFlush("Enter your personal email ID:-");
	scanf("%s",emp_data_struct.emp_per_inf.email_id);
	printfWithFlush("Enter your personal phone number:-");
	scanf("%s",emp_data_struct.emp_per_inf.phone_number);
	printfWithFlush("Enter the blood group:-");
	scanf("%s",emp_data_struct.emp_per_inf.blood_group);
	printfWithFlush("Enter the country of the residence:-");
	scanf("%s",emp_data_struct.emp_per_inf.country_of_residence);
	printfWithFlush("Enter the total number of family members in(number):-");
	scanf("%d",(int*)&emp_data_struct.emp_per_inf.total_family_numbers);
	showEmployeePersonalInfo();
}

void getEmployeeEducationalInfo()
{	
	printfWithFlush("Enter the name of the university:-");
	scanf("%[^\n]s",emp_data_struct.emp_edu_inf.university_name);
	printfWithFlush("Enter the name of the college:-");
	scanf("%[^\n]s",emp_data_struct.emp_edu_inf.college_name);
	printfWithFlush("Enter the year of graduation:-");
	scanf("%d",&emp_data_struct.emp_edu_inf.graduation_year);
	printfWithFlush("Enter the final grade in the percentage form:-");
	scanf("%f",&emp_data_struct.emp_edu_inf.final_grade);
	showEmployeeEducationalInfo();
}

void getEmployeeProfessionalInfo()
{
	printfWithFlush("Enter the name of the office location:-");
	scanf("%[^\n]s",emp_data_struct.emp_edu_inf.university_name);
	printfWithFlush("Enter the name of the department:-");
	scanf("%[^\n]s",emp_data_struct.emp_prf_inf.dept_name);
	printfWithFlush("Enter your position/grade:-");
	scanf("%s",&emp_data_struct.emp_prf_inf.grade);
	printfWithFlush("Enter the total years of experience :-");
	scanf("%d",(int*)&emp_data_struct.emp_prf_inf.total_yrs_Expr);
	printfWithFlush("Enter the current salary:-");
	scanf("%"PRIu64"",&emp_data_struct.emp_prf_inf.currrent_salary);
	showEmployeeProfessionalInfo();
}

void showEmployeePersonalInfo()
{
	printf("----------------WELCOME TO THE VERIFICATION PORTAL------------------------\n");
	printf("Dear %s, Kindly Verify the personal details that you have entered in our database:-\n",emp_data_struct.emp_per_inf.name);
	printf("----------------EMPLOYEE PERSONAL DETAILS------------------------\n");
	printf("Name:- %s\n",emp_data_struct.emp_per_inf.name);
	printf("Email ID:- %s\n",emp_data_struct.emp_per_inf.email_id);
	printf("Personal Phone Number:- %s\n",emp_data_struct.emp_per_inf.phone_number);
	printf("Blood Group:- %s\n",emp_data_struct.emp_per_inf.blood_group);
	printf("Country of residence:- %s\n",emp_data_struct.emp_per_inf.country_of_residence);
	printf("Total Family Members:- %d\n",emp_data_struct.emp_per_inf.total_family_numbers);
	isInfoCorrect()?printf("%s",info_success_msg) writeData2File(): printf("%s",info_fail_msg);
}

void showEmployeeEducationalInfo()
{
	printf("----------------WELCOME TO THE VERIFICATION PORTAL------------------------\n");
	printf("Dear %s, Kindly Verify the educational details that you have entered in our database:-\n",emp_data_struct.emp_per_inf.name);
	printf("-------------------EMPLOYEE EDUCATIONAL DETAILS---------------------------\n");
	printf("Name:- %s\n",emp_data_struct.emp_per_inf.name);
	printf("Univerity Name:- %s\n",emp_data_struct.emp_edu_inf.university_name);
	printf("College Name:- %s\n",emp_data_struct.emp_edu_inf.college_name);
	printf("Graduation Year:- %d\n",emp_data_struct.emp_edu_inf.graduation_year);
	printf("Final Grade in (Percentage):- %2.3f\n",emp_data_struct.emp_edu_inf.final_grade);
	isInfoCorrect()?printf("%s",info_success_msg) : printf("%s",info_fail_msg);
}

void showEmployeeProfessionalInfo()
{
	printf("----------------WELCOME TO THE VERIFICATION PORTAL------------------------\n");
	printf("Dear %s, Kindly Verify the educational details that you have entered in our database:-\n",emp_data_struct.emp_per_inf.name);
	printf("-------------------EMPLOYEE EDUCATIONAL DETAILS---------------------------\n");
	printf("Name:- %s\n",emp_data_struct.emp_per_inf.name);
	printf("Department Name:- %s\n",emp_data_struct.emp_prf_inf.dept_name);
	printf("Working Location:- %s\n",emp_data_struct.emp_prf_inf.location);
	printf("Grade/Position:- %s\n",emp_data_struct.emp_prf_inf.grade);
	printf("Total Years of Experience:- %d\n",(int)emp_data_struct.emp_prf_inf.total_yrs_Expr);
	printf("Current Salary:- %"PRIu64" \n",emp_data_struct.emp_prf_inf.currrent_salary );
	isInfoCorrect()?printf("%s",info_success_msg) : printf("%s",info_fail_msg);
}

RET_INFO_STAT_ENUM isInfoCorrect()
{	
	int ret_status = 0;
	printf("Is entered info correct : 1.Yes/ 0.No!?\n");
	scanf("%d", &ret_status);
	if(ret_status)
	{
		return INFO_CORRECT;
	}
	else if(!ret_status)
	{
		return INFO_INCONRRECT;
	}
	else{
		return -1;
	}

}

void printfWithFlush(const char str[])
{
	printf("%s\n",str);
	fflush(stdin);		// Use fflush while on Windows
}

void writeData2File()
{
	int i=0;
	for(i=0; i<)
}