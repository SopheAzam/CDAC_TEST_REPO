/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>

typedef struct{
    int x;
    char y;
};

struct{ // Anonymous futher object creation not possible
    int x;
    char y;
}anoymous_struct;


int main()
{
    anoymous_struct.x = 10;
    anoymous_struct.y = 20;
    printf("%d|%d\n",anoymous_struct.x,anoymous_struct.y);
    return 0;
}