/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>
#include<stddef.h>

union A
{
    int x;
    int y;
    char ch;
};

int main()
{
    union A au;
    au.x = 128;
    printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    au.y = 0x111;
    printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    au.ch = 'F';
    printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    printf("%d\n",sizeof(au));
    printf("%d\n",offsetof(union A,x));
    printf("%d\n",offsetof(union A,y));
    printf("%d\n",offsetof(union A,ch));
    return 0;
}