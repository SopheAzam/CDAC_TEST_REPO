/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>

struct A
{
int x;
char str[20]; // (or) char str[20];
};


int main()
{
    struct A a1={101,"abc"},a2;
    a1.x = 100;
  //  a1.str = "xyz";
    printf("%s\n",a1.str);
    printf("%d\n",&a1.x);
    a2 = a1;
    printf("%s\n",a2.str);
    printf("%d\n",a2.x);
}