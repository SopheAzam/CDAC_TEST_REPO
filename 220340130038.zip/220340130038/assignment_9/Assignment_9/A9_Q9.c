/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>
#include<stddef.h>

union A
{
        int x;
        float y;
        double z;
        int arr[2];
}a1;

union B
{
        int x;
        short int y;
        char z;
        char arr[4];
}b1;

int main()
{
   // union A au;
    //au.x = 128;
    a1.y=6.25f;
    printf("%d|%f|%f|%d|%d|\n",a1.x,a1.y,a1.z,a1.arr[0],a1.arr[1]);

    b1.x=0x12345678;
    printf("%x|%x|%x|%x|%x|%x|%x|\n",b1.x,b1.y,b1.z,b1.arr[0],b1.arr[1],b1.arr[2],b1.arr[3]);
    // printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    // au.y = 0x111;
    // printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    // au.ch = 'F';
    // printf("%d|%d|%d|\n",au.x,au.y,au.ch);
    // printf("%d\n",sizeof(au));
    // printf("%d\n",offsetof(union A,x));
    // printf("%d\n",offsetof(union A,y));
    // printf("%d\n",offsetof(union A,ch));
    return 0;
}