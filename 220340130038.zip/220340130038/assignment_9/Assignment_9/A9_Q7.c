/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>

typedef struct {
    int x;
    char y;

    struct{ // Anonymous futher object creation not possible
        int x;
        char y;
    }inner_anoymous_struct;

}outer_struct;

typedef struct {
    int x;
    char y;

    struct NAME{ // Anonymous futher object creation not possible
        int x;
        char y;
    }named_inner_struct;

}outer_struct_with_inner_named;

int main()
{
    outer_struct os;
    outer_struct_with_inner_named os2;
    struct NAME nm;
    nm.x = 10; // Possible but use?
    os.x = 10;
    os.y = 20;
    os2.named_inner_struct.x = 100;
    os.inner_anoymous_struct.x = 30;
    os.inner_anoymous_struct.y = 40;
    printf("%d\n",os2.named_inner_struct.x);
    printf("%d|%d|%d|%d|\n",os.x,os.y,os.inner_anoymous_struct.x,os.inner_anoymous_struct.y);
    return 0;
}