#ifndef _A9_Q1_HEADER_FILE_
#define _A9_Q1_HEADER_FILE_

#include<inttypes.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>

// User Defined Data Structures
typedef struct{
	char 	 name[50];
	char 	 blood_group[10];	
	char     email_id[50];
	char     phone_number[15];
	char 	 country_of_residence[20];
	char  	 residence_address[100];
	char 	 permanant_address[100];
	uint8_t  total_family_numbers; // why int is working and uint8_t not working ?
}EMPLOYEE_PERSONAL_INFO;

typedef struct{
	char     university_name[50];
	char     college_name[50];
	uint16_t graduation_year;
	float    final_grade;		
}EMPLOYEE_EDUCATIONAL_INFO;

typedef struct{
	char 	 dept_name[50];
	char     location[50];
	char     grade[20];
	uint8_t  total_yrs_Expr;
	uint64_t currrent_salary;

}EMPLOYEE_PROFESISONAL_INFO;

typedef struct{
	EMPLOYEE_PERSONAL_INFO 		emp_per_inf;
	EMPLOYEE_EDUCATIONAL_INFO 	emp_edu_inf;
	EMPLOYEE_PROFESISONAL_INFO	emp_prf_inf;
}EMPLOYEE_DATA_STRUCT;

typedef enum{
	EMPLOYEE_PERSONAL_INFO_ = 1,
	EMPLOYEE_EDUCATIONAL_INFO_,
	EMPLOYEE_PROFESISONAL_INFO_
}EMPLOYEE_INFO_ENUM;

typedef enum{
	INFO_INCONRRECT=0,
	INFO_CORRECT
}RET_INFO_STAT_ENUM;

const char* info_success_msg = "Your information stored successfully in the database!";
const char* info_fail_msg = "An error while storing the information the database, Reason:- Incorrect Information!";

// Function Prototypes
void ui_dashboard(void);
void getEmployeePersonalInfo(void);
void showEmployeePersonalInfo(void);
void getEmployeeEducationalInfo(void);
void showEmployeeEducationalInfo(void);
void getEmployeeProfessionalInfo(void);
void showEmployeeProfessionalInfo(void);
void printfWithFlush(const char str[]);
RET_INFO_STAT_ENUM isInfoCorrect(void);


#endif
