/*
*@author: Ashish Hemant Jog
*@Date:    /04/2022
*@Description: 
*/
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>

typedef union{
    uint32_t int_var;
    struct 
    {
        uint8_t byte1;
        uint8_t byte2;
        uint8_t byte3;
        uint8_t byte4;
    }byteStruct;
}_4byte2singlebyteunion;

typedef union{
    uint8_t singleByte;
    struct 
    {
        uint8_t bit1:1; // bitfield
        uint8_t bit2:1;
        uint8_t bit3:1;
        uint8_t bit4:1;
        uint8_t bit5:1;
        uint8_t bit6:1;
        uint8_t bit7:1;
        uint8_t bit8:1;
    }bitStruct;
}_1byteto8Bitsunion;

typedef struct
{
    uint8_t byte1;
    uint8_t byte2;
    uint8_t byte3;
    uint8_t byte4;
    typedef struct
    {
        uint8_t byte1;
        uint8_t byte2;
        uint8_t byte3;
        uint8_t byte4;
    }inner_struct;
    
}outer_struct;


int main()
{
    _4byte2singlebyteunion int2byte;
    int2byte.int_var = 0x12345678;

    printf("byte number 1 = %x\n",int2byte.byteStruct.byte1);
    printf("byte number 2 = %x\n",int2byte.byteStruct.byte2);
    printf("byte number 3 = %x\n",int2byte.byteStruct.byte3);
    printf("byte number 4 = %x\n",int2byte.byteStruct.byte4);

    _1byteto8Bitsunion byte2bit;

    byte2bit.singleByte = 0xAB;

    printf("bit number 1 = %x\n",byte2bit.bitStruct.bit1);
    printf("bit number 2 = %x\n",byte2bit.bitStruct.bit2);
    printf("bit number 3 = %x\n",byte2bit.bitStruct.bit3);
    printf("bit number 4 = %x\n",byte2bit.bitStruct.bit4);
    printf("bit number 5 = %x\n",byte2bit.bitStruct.bit5);
    printf("bit number 6 = %x\n",byte2bit.bitStruct.bit6);
    printf("bit number 7 = %x\n",byte2bit.bitStruct.bit7);
    printf("bit number 8 = %x\n",byte2bit.bitStruct.bit8);
    
    return 0;
}