#include<stdio.h>
//#define DEBUG
int countbinary(int,int *,int *);

int main(){
	int a,zeros=0,ones=0,*p,*q;
	p=&zeros;
	q=&ones;
	printf("enter binary number\n");
	scanf("%d",&a);
	countbinary(a,p,q);
	printf("total number of zeros=%d ones=%d\n",zeros,ones);

}
int countbinary(int a,int *p,int *q){
	#ifdef DEBUG
	printf("*p=%d\n",*p);
	#endif
	if(a==0)
		return 0;
	if(a%2==0){
		(*p)++;
	}
	else
		(*q)++;

	countbinary(a/10,p,q);
}
