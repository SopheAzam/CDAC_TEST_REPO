#include<stdio.h>
void decimaltoBO(int,int);
int main(){
	int num,choice;
	printf("enter decimal number\n");
	scanf("%d",&num);
	printf("enter 2 for binary\nenter 8 for octal\n");
	scanf("%d",&choice);
	printf("output is\n");
	decimaltoBO(num,choice);
	printf("\n");
}
void decimaltoBO(int n,int c){
	if(n==0)
		return;
	decimaltoBO(n/c,c);
	printf("%d",n%c);

	
	
}
