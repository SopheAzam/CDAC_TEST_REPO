// Array Print and reversal using recursion//

#include<stdio.h>
void print_Array(int,int [],int);
void print_reverseArray(int,int []);
int main(){
	int size,choice;
	while(1){
	printf("enter size of array\n");
	scanf("%d",&size);
	int arr[size];

	for(int i=0;i<size;i++){
		printf("enter %d element of array\t",i+1);
		scanf("%d",&arr[i]);
	}
	printf("pres\n1 for print array\n2 for reverse print of array\n");
	scanf("%d",&choice);
	printf("\n");
	print_Array(size,arr,choice);
	}
///////////////////////if in case use of two function is important use this commented part//////////////////
	/*switch(choice){
		case 1:
			print_Array(size,arr,choice);
			break;
		case 2:
			print_reverseArray(size,arr);
			break;
		default:
			printf("invalid input");
	}*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}

void print_Array(int size,int arr[],int choice){
	if(choice==2){
		if(size==0)
			return ;
		printf("%d\n",arr[size-1]);
		print_Array(size-1,arr,choice);
	}
	else if(choice==1){
		if(size==0)
			return ;
	print_Array(size-1,arr,choice);
	printf("%d\n",arr[size-1]);
	}
}





////////////////////////if in case use two different function take thin////////////////////////
void print_reverseArray(int size,int arr[]){
	return;
}

