#include<stdio.h>
int GCD(int,int,int);
int main(){
	int num1,num2,min;
	printf("enter two numbers separated by space\n");
	scanf("%d %d",&num1,&num2);
	min=num1<num2?num1:num2;
	printf("answer is %d\n",GCD(num1,num2,min));

}
int GCD(int a,int b,int min){
	if(a%min==0&&b%min==0)
		return min;
	else
		GCD(a,b,min-1);
}
