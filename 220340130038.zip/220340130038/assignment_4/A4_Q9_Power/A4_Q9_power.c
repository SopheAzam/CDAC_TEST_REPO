#include<stdio.h>

int power(int,int);
int main(){
	int num,pow;
	printf("enter number and power\n");
	scanf("%d %d",&num,&pow);
	printf("power is %d\n",power(num,pow));
}
int power(int num,int p){
	if(p==0)
		return 1;
	num*=power(num,--p);
	return num;
}
