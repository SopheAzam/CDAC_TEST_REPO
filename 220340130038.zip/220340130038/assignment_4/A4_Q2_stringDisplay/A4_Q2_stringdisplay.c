//print and reverse of string//

#include<stdio.h>
#include<string.h>
#define SIZE 10

void revstring(char *,int);
int main(){
	char arr[SIZE];
	fgets(arr,SIZE,stdin);
	revstring(arr,strlen(arr));
	printf("\n");
}
void revstring(char *a, int len){
	if(len==0){
		return;
	}
	printf("%c",*(a+len-1));
	revstring(a,len-1);
}
