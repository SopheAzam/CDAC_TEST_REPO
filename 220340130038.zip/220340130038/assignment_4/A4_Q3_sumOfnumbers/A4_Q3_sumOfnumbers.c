#include<stdio.h>
int sumofnumber(int);
int main(){
	int input,result;
	printf("enter number\n");
	scanf("%d",&input);
	result=sumofnumber(input);
	printf("result is %d\n",result);
}
int sumofnumber(int n){
	if(n!=0)
		return  n+=sumofnumber(n-1);

}
