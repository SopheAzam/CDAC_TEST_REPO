#include<stdio.h>
int fact(int);
int main(){
	int num,result;
	printf("enter input\n");
	scanf("%d",&num);
	result=fact(num);
	printf("result is %d\n",result);	
}
int fact(int n){
	if(n==0){
		printf("value of n is %d\n",n);
		return 1;
	}
	else{
		printf("in else\n");
		return n*=fact(n-1);
	}

}
