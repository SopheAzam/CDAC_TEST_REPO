#include<stdio.h>
void fiboseries(int,int,int);
int main(){
	int num1,num2,len;
	printf("enter 1st two number separated by space\n");
	scanf("%d %d",&num1,&num2);
	printf("enter length of fibonacci series\n");
	scanf("%d",&len);
	printf("%d ",num1);
	fiboseries(num1,num2,len);
	printf("\n");
}
void fiboseries(int n1,int n2,int l){
	if(l==0)
		return;
	printf("%d ",n2);
	int sum=n1+n2;
	n1=n2;
	n2=sum;
	fiboseries(n1,n2,l-1);

}
