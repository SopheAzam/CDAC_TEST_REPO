#include<stdio.h>

int countDigit(int);

int main(){
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	printf("result is %d\n",countDigit(num));

}
int countDigit(int n){
	int count=1;
	if(n==0)
		return 0;
	count+=countDigit(n/10);
	return count;
}
