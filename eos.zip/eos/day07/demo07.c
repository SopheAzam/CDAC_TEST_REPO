#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main() {
    int fd;
    fd = open("temp.txt", O_CREAT, 0777);
    if(fd < 0) {
        perror("open() failed");
        _exit(1);
    }
    printf("file created: %d\n", fd);
    close(fd);
    return 0;
}
