#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd1, fd2, fd3;
    
    fd1 = open("/home/nilesh/.bashrc", O_RDONLY);
    printf("open() - %d\n", fd1);

    fd2 = open("/home/nilesh/.profile", O_RDONLY);
    printf("open() - %d\n", fd2);
    close(fd1);

    fd3 = open("/home/nilesh/.bashrc", O_RDONLY);
    printf("open() - %d\n", fd3);
    close(fd3);

    close(fd2);


    return 0;
}