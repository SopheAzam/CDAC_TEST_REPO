#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#define SERVER_IP   "172.18.4.134"
#define SERVER_PORT 2709

void str_upper(char *str) {
    int i;
    for(i=0; str[i]!='\0'; i++) {
        if(str[i] >= 'a' && str[i] <= 'z')
            str[i] -= 32;
        sleep(1);
    }
}

int serv_fd;

void sigint_handler(int sig) {
    // step 13: shutdown server socket
    shutdown(serv_fd, SHUT_RDWR);
    printf("server socket shutdown.\n");

    close(serv_fd);
    _exit(0);
}

void sigchld_handler(int sig) {
    int s;
    waitpid(-1, &s, 0);
}

// server
int main() {
    int pid, ret, cli_fd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t sock_len = sizeof(struct sockaddr_in);
    char msg[512];
    struct sigaction sa;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigchld_handler;
    ret = sigaction(SIGCHLD, &sa, NULL);

    // step 1: create server socket
    serv_fd = socket(AF_INET, SOCK_STREAM, 0);
    printf("server socket created: %d\n", serv_fd);
    // step 2: bind addr to server socket
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    inet_aton(SERVER_IP, &serv_addr.sin_addr);
    ret = bind(serv_fd, (struct sockaddr*)&serv_addr, sock_len);
    printf("server socket address bound: %d\n", ret);
    // step 3: listen to server socket
    listen(serv_fd, 5);
    printf("listening to server socket.\n");
    while(1) {
        // step 6: accept the client connection
        memset(&cli_addr, 0, sizeof(serv_addr));
        cli_fd = accept(serv_fd, (struct sockaddr*)&cli_addr, &sock_len);
        if(cli_fd <= 0) {
            perror("accept failed");
            if(errno == EINTR) // interrupted due to signal -- SIGCHLD
                continue;
            perror("accept() failed");
            sigint_handler(SIGINT);
            _exit(1);
        }
        printf("client connection accepted: %d\n", cli_fd);
        
        pid = fork();
        if(pid == 0) {
            // step 8: read from client
            read(cli_fd, msg, sizeof(msg));
            printf("client: %s\n", msg);
            str_upper(msg);
            // step 9: write to client
            write(cli_fd, msg, strlen(msg)+1);
            // step 12: close socket
            close(cli_fd);
            _exit(0);
        }
        close(cli_fd);
    }
    return 0;
}





