#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

struct shm {
    int count;
};

int main() {
    struct shm *ptr;
    int i, ret, s;

    ptr = malloc(sizeof(struct shm));
    if(ptr == NULL) {
        perror("malloc() failed");
        exit(1);
    }
    ptr->count = 0;

    ret = fork();
    if(ret == 0) {
        for(i=1; i<=10; i++) {
            ptr->count++;
            printf("child: %d\n", ptr->count);
            sleep(1);
        }
        free(ptr);
        _exit(0);
    }
    else {
        for(i=1; i<=10; i++) {
            ptr->count--;
            printf("parent: %d\n", ptr->count);
            sleep(1);
        }
        waitpid(-1, &s, 0);
        printf("final count = %d\n", ptr->count);    
        free(ptr);
        ptr = NULL;
    }
    return 0;
}

