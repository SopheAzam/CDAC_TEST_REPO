#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>

// race condition
#define SHM_KEY 0x1234

struct shm {
    int count;
};

int main() {
    struct shm *ptr;
    int i, ret, s, shmid;

    shmid = shmget(SHM_KEY, sizeof(struct shm), IPC_CREAT | 0644);
    if(shmid < 0) {
        perror("shmget() failed");
        _exit(1);
    }

    ptr = shmat(shmid, NULL, 0);
    if(ptr == (void*)-1) {
        perror("shmat() failed");
        exit(1);
    }
    ptr->count = 0;

    ret = fork();
    if(ret == 0) {
        for(i=1; i<=10; i++) {
            ptr->count++;
            printf("child: %d\n", ptr->count);
            sleep(1);
        }
        shmdt(ptr);
        _exit(0);
    }
    else {
        for(i=1; i<=10; i++) {
            ptr->count--;
            printf("parent: %d\n", ptr->count);
            sleep(1);
        }
        waitpid(-1, &s, 0);

        printf("final count = %d\n", ptr->count);    

        shmdt(ptr);
        ptr = NULL;
    
        shmctl(shmid, IPC_RMID, NULL);
    }
    return 0;
}

