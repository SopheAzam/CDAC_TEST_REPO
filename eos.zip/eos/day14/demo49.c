#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <sys/sem.h>

// semaphore as mutual exclusion
#define SHM_KEY 0x1234
#define SEM_KEY 0x2345

struct shm {
    int count;
};

union semun {
    int              val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO (Linux-specific) */
};


int main() {
    struct shm *ptr;
    int i, ret, s, shmid, semid;
    union semun su;
    struct sembuf sops[1];

    // create semaphore with single counter
    semid = semget(SEM_KEY, 1, IPC_CREAT | 0644);
    if(semid < 0) {
        perror("semget() failed");
        _exit(1);
    }

    // sem = 1
    su.val = 1;
    ret = semctl(semid, 0, SETVAL, su);
    if(ret < 0) {
        perror("semctl() failed to init semaphore");
        _exit(2);
    }

    shmid = shmget(SHM_KEY, sizeof(struct shm), IPC_CREAT | 0644);
    if(shmid < 0) {
        perror("shmget() failed");
        _exit(3);
    }

    ptr = shmat(shmid, NULL, 0);
    if(ptr == (void*)-1) {
        perror("shmat() failed");
        exit(4);
    }
    ptr->count = 0;

    ret = fork();
    if(ret == 0) {
        for(i=1; i<=10; i++) {
            // P(sem);
            sops[0].sem_num = 0;
            sops[0].sem_op = -1;
            sops[0].sem_flg = 0;
            ret = semop(semid, sops, 1);
            
            ptr->count++;
            printf("child: %d\n", ptr->count);
            // V(sem);
            sops[0].sem_num = 0;
            sops[0].sem_op = +1;
            sops[0].sem_flg = 0;
            ret = semop(semid, sops, 1);

            sleep(1);
        }
        shmdt(ptr);
        _exit(0);
    }
    else {
        for(i=1; i<=10; i++) {
            // P(sem);
            sops[0].sem_num = 0;
            sops[0].sem_op = -1;
            sops[0].sem_flg = 0;
            ret = semop(semid, sops, 1);

            ptr->count--;
            printf("parent: %d\n", ptr->count);

            // V(sem);
            sops[0].sem_num = 0;
            sops[0].sem_op = +1;
            sops[0].sem_flg = 0;
            ret = semop(semid, sops, 1);

            sleep(1);
        }
        waitpid(-1, &s, 0);

        printf("final count = %d\n", ptr->count);    

        shmdt(ptr);
        ptr = NULL;
    
        shmctl(shmid, IPC_RMID, NULL);
        
        // destroy semaphore
        semctl(semid, 0, IPC_RMID);
    }
    return 0;
}
