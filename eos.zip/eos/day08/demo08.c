#include <stdio.h>
#include <unistd.h>

int main() {
    //fork();
    createprocess();
    printf("hello, world!\n");
    return 0;
}
