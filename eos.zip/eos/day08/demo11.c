#include <stdio.h>
#include <unistd.h>

int main() {
    int i, ret;
    printf("program started!\n");
    ret = fork();
    if(ret == 0) {
        printf("child: fork() returned: %d\n", ret);
        for(i=0; i<300; i++) {
            printf("child: %d\n", i);
        }
        printf("child: program completed!\n");
    }
    else {
        printf("parent: fork() returned: %d\n", ret);
        for(i=0; i<300; i++) {
            printf("parent: %d\n", i);
        }
        printf("parent: program completed!\n");
    }
    return 0;
}
