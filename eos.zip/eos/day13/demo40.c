#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {
    int cnt, ret, pfd[2];
    char str1[32] = "Hello DESD!\n", str2[32]; 
    ret = pipe(pfd);
    if(ret < 0) {
        perror("pipe() failed");
        _exit(1);
    }
    //pfd[1] -- writer fd and pfd[0] -- reader fd
    
    printf("writing into pipe: %s\n", str1);
    write(pfd[1], str1, strlen(str1)+1);
    printf("reading from pipe.\n");
    cnt = read(pfd[0], str2, sizeof(str2));
    printf("read %d bytes from pipe: %s\n", cnt, str2);

    close(pfd[1]);
    close(pfd[0]);
    return 0;
}