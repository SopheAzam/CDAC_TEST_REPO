#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCK_FILE "desd_sock"

// client
int main() {
    int ret, cli_fd;
    struct sockaddr_un serv_addr;
    socklen_t sock_len = sizeof(struct sockaddr_un);
    char msg[512];

    // step 4: create client socket
    cli_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    printf("client socket created: %d\n", cli_fd);
    // step 5: connect to server socket
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sun_family = AF_UNIX;
    strcpy(serv_addr.sun_path, SOCK_FILE);
    ret = connect(cli_fd, (struct sockaddr*)&serv_addr, sock_len);
    printf("connected to server socket: %d\n", ret);
    do {
        // step 7: write to server
        printf("client: ");
        gets(msg);
        write(cli_fd, msg, strlen(msg)+1);
        // step 10: read from server
        read(cli_fd, msg, sizeof(msg));
        printf("server: %s\n", msg);
    }while(strcmp(msg, "bye") != 0);
    // step 11: close socket
    close(cli_fd);
    printf("socket closed.\n");
    return 0;
}
