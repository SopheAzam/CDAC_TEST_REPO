#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

// race condition
int count = 0;

void* inc_func(void *param) {
    int i;
    for(i=1; i<=10; i++) {
        count++;
        printf("inc : %d\n", count);
        sleep(1);
    }
    return NULL;
}

void* dec_func(void *param) {
    int i;
    for(i=1; i<=10; i++) {
        count--;
        printf("dec : %d\n", count);
        sleep(1);
    }
    return NULL;
}

int main() {
    int i, ret;
    pthread_t t1, t2;
    ret = pthread_create(&t1, NULL, inc_func, NULL);
    ret = pthread_create(&t2, NULL, dec_func, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("final count = %d\n", count);
    return 0;
}


