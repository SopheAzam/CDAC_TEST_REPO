#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void* func1(void *param) {
    int i;
    for(i=1; i<=5; i++) {
        printf("func1: %d\n", i);
        sleep(1);
    }
    return NULL;
}

void* func2(void *param) {
    int i;
    for(i=1; i<=10; i++) {
        printf("func2: %d\n", i);
        sleep(1);
        if(i == 7)
            pthread_exit(NULL);
    }
    return NULL;
}

void* func3(void *param) {
    int i;
    for(i=1; i<=10; i++) {
        printf("func3: %d\n", i);
        sleep(1);
    }
    return NULL;
}

int main() {
    int i, ret;
    pthread_t t1, t2, t3;
    ret = pthread_create(&t1, NULL, func1, NULL);
    ret = pthread_create(&t2, NULL, func2, NULL);
    ret = pthread_create(&t3, NULL, func3, NULL);
    for(i=1; i<=2; i++) {
        printf("main : %d\n", i);
        sleep(1);
    }

    printf("main: press enter to cancel thread3...\n");
    getchar();
    pthread_cancel(t3);
    
    printf("main: press enter to exit...\n");
    getchar();
    return 0;
}


