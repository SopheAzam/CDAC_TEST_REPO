#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void* print_table(void *param) {
    long i, num = (long)param, sum = 0;
    for(i=1; i<=10; i++) {
        printf("%ld * %ld = %ld\n", num, i, num * i);
        sum += num * i;
        sleep(1);
    }
    //pthread_exit((void*)sum);     // OR
    return (void*)sum;
}

int main() {
    pthread_t t1, t2, t3;
    void *result;
    pthread_create(&t1, NULL, print_table, (void*)3L);
    pthread_create(&t2, NULL, print_table, (void*)5L);
    pthread_create(&t3, NULL, print_table, (void*)7L);
    printf("main thread is waiting for thread results...\n");
    pthread_join(t1, &result); // pause current thread (main) for t1 and get its result.
    printf("t1 result: %ld\n", (long)result);
    pthread_join(t2, &result); // pause current thread (main) for t2 and get its result.
    printf("t2 result: %ld\n", (long)result);
    pthread_join(t3, &result); // pause current thread (main) for t3 and get its result.
    printf("t3 result: %ld\n", (long)result);
    printf("bye!\n");
    return 0;
}
