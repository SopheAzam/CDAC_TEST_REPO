#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>

// problem stmt: if signal is sent to the thread, terminate that thread; 
//          but if signal is sent to the main thread (process), terminate that process.
void sigint_handler(int sig) {
    printf("SIGINT caught by process %d thread %d\n", getpid(), gettid());

    // for main thread, pid and tid both are same
    if(gettid() == getpid()) // if signal is received by main thread,
        _exit(0);               // then terminate whole process
    else                    // otherwise
        pthread_exit(NULL);     // terminate that thread
}

void* func1(void *param) {
    int i;
    printf("process id : %d\n", getpid());
    printf("thread id : %d\n", gettid());
    for(i=1; i<=10; i++) {
        printf("func1: %d\n", i);
        sleep(1);
    }
    return NULL;
}

int main() {
    int i, ret;
    pthread_t t1;
    struct sigaction sa;
    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);

    printf("process id : %d\n", getpid());
    printf("thread id : %d\n", gettid());
    ret = pthread_create(&t1, NULL, func1, NULL);
    for(i=1; i<=3; i++) {
        printf("main : %d\n", i);
        sleep(1);
    }
    printf("press enter to send signal to the thread...\n");
    getchar();
    pthread_kill(t1, SIGINT);
    printf("press enter to exit...\n");
    getchar();
    printf("bye!\n");
    return 0;
}


