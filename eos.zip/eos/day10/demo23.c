#include <unistd.h>
#include <stdio.h>

int main() {
    int ret;
    ret = fork();
    if(ret == 0) {
        printf("child: pid = %d\n", getpid());
        printf("child: parent pid = %d\n", getppid());
    } else {
        printf("parent: pid = %d\n", getpid());
        printf("parent: parent pid = %d\n", getppid());
    }
    return 0;
}

