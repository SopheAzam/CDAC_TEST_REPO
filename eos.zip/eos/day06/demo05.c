#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>

int main(int argc, char *argv[]) {
    char *dirpath;
    DIR *dp;
    struct dirent *ent;
    struct stat st;
    int ret;

    if(argc != 2) {
        fprintf(stderr, "%s <dir-path>\n", argv[0]);
        exit(1);
    }
    dirpath = argv[1];

    ret = chdir(dirpath);
    if(ret < 0) {
        perror("chdir() failed");
        exit(3);
    }

    dp  = opendir(dirpath);
    if(dp == NULL) {
        perror("opendir() failed");
        exit(2);
    }

    while( (ent = readdir(dp)) != NULL ) {
        printf("%-9lu", ent->d_ino);       
        ret = stat(ent->d_name, &st);
        if(ret < 0) {
            perror("stat() failed");
            continue;
        }
        printf("%-8o", st.st_mode);       
        printf("%-4lu", st.st_nlink);       
        printf("%-6u%-6u", st.st_uid, st.st_gid);
        printf("%-12lu", st.st_size);       
        printf("%s\n", ent->d_name);       
    }

    closedir(dp);
    return 0;
}