#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

// bounded buffer solution -- circular buffer in shared memory
    // writer should be blocked when buffer is full. "se" (1) empty counter.
    // reader should be blocked when buffer is empty. "sf" (2) filled counter.
    // only one process should access the resource at a time. "sm" (0) mutual exclusion.

#define MAX 5

struct cirque {
    int arr[MAX];
    int front, rear;
    int count;
};

void cq_init(struct cirque *q) {
    memset(q->arr, 0, sizeof(q->arr));
    q->front = -1;
    q->rear = -1;
    q->count = 0;
}

void cq_push(struct cirque *q, int val) {
    q->rear = (q->rear + 1) % MAX;
    q->arr[q->rear] = val;    
    q->count++;
}

int cq_pop(struct cirque *q) {
    int val;
    q->front = (q->front + 1) % MAX;
    val = q->arr[q->front];    
    q->count--;
    return val;
}

int cq_empty(struct cirque *q) {
    return q->count == 0 ? 1 : 0;
}

int cq_full(struct cirque *q) {
    return q->count == MAX ? 1 : 0;
}

#define SHM_KEY 0x1234
#define SEM_KEY 0x5678

#define SEM_MUT     0
#define SEM_EMP     1
#define SEM_FIL     2

int shmid;
int semid;
struct cirque *q;

union semun {
    int              val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO (Linux-specific) */
};

void sigint_handler(int sig) {
    shmdt(q);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    _exit(0);
}

int main() {
    int val, ret;
    struct sigaction sa;
    unsigned short sem_init[3] = { 1, MAX, 0 };
    union semun su;
    struct sembuf sops[2];

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);

    semid = semget(SEM_KEY, 3, IPC_CREAT | 0600);

    su.array = sem_init;
    semctl(semid, 0, SETALL, su);

    shmid = shmget(SHM_KEY, sizeof(struct cirque), IPC_CREAT | 0600);
    q = (struct cirque *) shmat(shmid, NULL, 0);
    cq_init(q);
    
    ret = fork();
    if(ret == 0) {
        // child -- writer
        while(1) {
            // P(se,sm);
            sops[0].sem_num = SEM_EMP;
            sops[0].sem_op = -1;
            sops[0].sem_flg = 0;
            sops[1].sem_num = SEM_MUT;
            sops[1].sem_op = -1;
            sops[1].sem_flg = 0;
            ret = semop(semid, sops, 2);

            val = rand() % 100;
            cq_push(q, val);    
            printf("WR: %d\n", val);
            sleep(1);

            // V(sf,sm);
            sops[0].sem_num = SEM_FIL;
            sops[0].sem_op = +1;
            sops[0].sem_flg = 0;
            sops[1].sem_num = SEM_MUT;
            sops[1].sem_op = +1;
            sops[1].sem_flg = 0;
            ret = semop(semid, sops, 2);
        }
    }
    else {
        // parent -- reader
        sleep(10);
        while(1) {
            // P(sf,sm);
            sops[0].sem_num = SEM_FIL;
            sops[0].sem_op = -1;
            sops[0].sem_flg = 0;
            sops[1].sem_num = SEM_MUT;
            sops[1].sem_op = -1;
            sops[1].sem_flg = 0;
            ret = semop(semid, sops, 2);

            val = cq_pop(q);    
            printf("RD: %d\n", val);
            sleep(1);

            // V(se,sm);
            sops[0].sem_num = SEM_EMP;
            sops[0].sem_op = +1;
            sops[0].sem_flg = 0;
            sops[1].sem_num = SEM_MUT;
            sops[1].sem_op = +1;
            sops[1].sem_flg = 0;
            ret = semop(semid, sops, 2);
        }
    }
    return 0;
}

