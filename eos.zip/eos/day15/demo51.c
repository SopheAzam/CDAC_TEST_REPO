#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

// bounded buffer problem -- circular buffer in shared memory
    // writer should be blocked when buffer is full.
    // reader should be blocked when buffer is empty.
    // only one process should access the resource at a time.

#define MAX 5

struct cirque {
    int arr[MAX];
    int front, rear;
    int count;
};

void cq_init(struct cirque *q) {
    memset(q->arr, 0, sizeof(q->arr));
    q->front = -1;
    q->rear = -1;
    q->count = 0;
}

void cq_push(struct cirque *q, int val) {
    q->rear = (q->rear + 1) % MAX;
    q->arr[q->rear] = val;    
    q->count++;
}

int cq_pop(struct cirque *q) {
    int val;
    q->front = (q->front + 1) % MAX;
    val = q->arr[q->front];    
    q->count--;
    return val;
}

int cq_empty(struct cirque *q) {
    return q->count == 0 ? 1 : 0;
}

int cq_full(struct cirque *q) {
    return q->count == MAX ? 1 : 0;
}

#define SHM_KEY 0x1234

int shmid;
struct cirque *q;

void sigint_handler(int sig) {
    shmdt(q);
    shmctl(shmid, IPC_RMID, NULL);
    _exit(0);
}

int main() {
    int val, ret;
    struct sigaction sa;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);

    shmid = shmget(SHM_KEY, sizeof(struct cirque), IPC_CREAT | 0600);
    q = (struct cirque *) shmat(shmid, NULL, 0);
    cq_init(q);
    
    ret = fork();
    if(ret == 0) {
        // child -- writer
        sleep(10);
        while(1) {
            val = rand() % 100;
            cq_push(q, val);    
            printf("WR: %d\n", val);
            sleep(1);
        }
    }
    else {
        // parent -- reader
        while(1) {
            val = cq_pop(q);    
            printf("RD: %d\n", val);
            sleep(1);
        }
    }
    return 0;
}

