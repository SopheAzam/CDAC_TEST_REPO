#include <stdio.h>
#include <unistd.h>

int main() {
    char str[] = "Hello, World!\n";
    // print "hello, world!"
	write(2, str, 14);
    // terminate current process
    _exit(7);
}

// standard file descriptors
//  0 - stdin
//  1 - stdout
//  2 - stderr

// _exit(n)
//  arg1: exit code (0 indicate success, non-zero indicate failure)

// ret = write(fd, buf, len);
//  arg1: file descriptor
//  arg2: base address of buffer to write
//  arg3: number of bytes to write
//  returns: number of bytes successfully written

// terminal> gcc demo02.c
// terminal> ./a.out
// terminal> echo $?

// $? -- special bash variable -- exit status of last executed program
