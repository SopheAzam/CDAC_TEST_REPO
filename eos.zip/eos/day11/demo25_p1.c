#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include "demo25.h"

int main() {
    int mqid, ret;
    struct msg m1;
    // create message queue
    mqid = msgget(MQ_KEY, IPC_CREAT | 0600);
    if(mqid < 0) {
        perror("P1: msgget() failed");
        _exit(1);
    }

    // get a string from user
    printf("P1: enter a string: ");
    scanf("%s", m1.data);
    // sent string to message queue
    m1.type = MSG_TYPE1;
    ret = msgsnd(mqid, &m1, sizeof(m1.data), 0);
    printf("P1: message sent : %d\n", ret);    
    return 0;
}
