#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/msg.h>

#define MQ_KEY  0x00002809

struct msg {
    long type;
    char data[32];
};

int main() {
    int ret, mqid, s;
    
    // create message queue
    mqid = msgget(MQ_KEY, IPC_CREAT | 0600);
    if(mqid < 0) {
        perror("msgget() failed");
        _exit(1);
    }

    ret = fork();
    if(ret == 0) {
        // child process
        struct msg m2;
        // get string from msg queue
        printf("child: waiting for the message...\n");
        ret = msgrcv(mqid, &m2, sizeof(m2.data), 11, 0);
        if(ret < 0)
            printf("child: msgrcv() failed");
        else
            // display the string
            printf("child: msg received: %s\n", m2.data);
        // exit
        _exit(0);
    }
    else {
        // parent process
        struct msg m1;
        // get a string from user
        printf("parent: enter a string: ");
        scanf("%s", m1.data);
        // send string in msg queue
        m1.type = 11;
        ret = msgsnd(mqid, &m1, sizeof(m1.data), 0);
        printf("parent: msg sent: %d\n", ret);
        // wait for child to exit
        waitpid(-1, &s, 0);
    }

    // destroy the message queue
    msgctl(mqid, IPC_RMID, NULL);
    return 0;
}

