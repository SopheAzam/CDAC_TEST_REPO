#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include "demo25.h"

int main() {
    int mqid, ret;
    struct msg m2;
    // access message queue
    mqid = msgget(MQ_KEY, 0);
    if(mqid < 0) {
        perror("P2: msgget() failed");
        _exit(1);
    }

    // get string from the message queue
    ret = msgrcv(mqid, &m2, sizeof(m2.data), MSG_TYPE1, 0);
    if(ret < 0)
        printf("P2: msgrcv() failed");
    else
        // display the string
        printf("P2: msg received: %s\n", m2.data);
    
    // destroy the message queue
    msgctl(mqid, IPC_RMID, NULL);
    return 0;
}
