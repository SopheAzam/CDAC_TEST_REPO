#ifndef __DEMO25_H
#define __DEMO25_H

#define MQ_KEY 0x00001234

struct msg {
    long type;
    char data[32];
};

#define MSG_TYPE1   111

#endif
