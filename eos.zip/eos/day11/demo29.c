#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void mysig_handler(int sig) {
    switch(sig) {
        case SIGINT:
            printf("SIGINT caught: %d\n", sig);
            break;
        case SIGTERM:
            printf("SIGTERM caught: %d\n", sig);
            break;
        case SIGHUP:
            printf("SIGHUP caught: %d\n", sig);
            break;
    }
}

int main() {
    int i=1;
    signal(SIGINT, mysig_handler);
    signal(SIGTERM, mysig_handler);
    signal(SIGHUP, mysig_handler);
    
    while(1) {
        printf("running: %d\n", i++);
        sleep(1);
    }
    return 0;
}

