#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig) {
    printf("SIGINT caught: %d\n", sig);
}

void sigterm_handler(int sig) {
    printf("SIGTERM caught: %d\n", sig);
}

void sighup_handler(int sig) {
    printf("SIGHUP caught: %d\n", sig);
}


int main() {
    int i=1;
    signal(SIGINT, sigint_handler);
    signal(SIGTERM, sigterm_handler);
    signal(SIGHUP, sighup_handler);
    
    while(1) {
        printf("running: %d\n", i++);
        sleep(1);
    }
    return 0;
}

