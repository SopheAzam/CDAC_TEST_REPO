#include <stdio.h>

int num = 10;

int main() {
	printf("Hello, Linux!\n");
	return 0;
}

// sudo apt install gcc gcc-multilib

// gcc -m32 demo01.c
// ./a.out


