#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>


int main(int argc, char *argv[]) {
    char *path = NULL;
    struct stat sb;
    int ret;

    if(argc != 2) {
        printf("file/dir path is not mentioned.\n");
        printf("%s <file-path>\n", argv[0]);
        exit(2);
    }
    path = argv[1];

    ret = stat(path, &sb);
    if(ret < 0) {
        perror("stat() failed");
        exit(3);
    }

    printf("inode = %lu\n", sb.st_ino);
    printf("size = %lu\n", sb.st_size);
    printf("mode = %o\n", sb.st_mode);
    printf("links = %lu\n", sb.st_nlink);
    printf("uid = %u, gid = %u\n", sb.st_uid, sb.st_gid);
    
    return 0;
}
