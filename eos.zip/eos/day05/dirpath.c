#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>

int main(int argc, char *argv[])
{
	char *dirpath = NULL;
	DIR *dp;
	struct dirent *ent;

	if(argc!=2)
	{
		printf("Directory Path is not mentioned.\n");
		printf("%s <dir-path>\n", argv[0]);
		exit(2);
	}
	dirpath = argv[1];

	dp=opendir(dirpath);
	if(dp==NULL)
	{
		perror("opendir() failed");
		exit(1);
	}
	while((ent = readdir(dp)) != NULL)
	{
		printf("%lu, %s\n",ent->d_ino,ent->d_name);
	}
	closedir(dp);
	return 0;
}
