#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int ret, s, err;
    printf("parent started!\n");
    ret = fork();
    if(ret == 0) {
        // output redirection
        int fd = open("out.txt", O_WRONLY | O_TRUNC | O_CREAT, 0644); // fd = 3
        // error check
        close(1);
        dup(fd);
        close(fd);
        
        // error redirection
        fd = open("err.txt", O_WRONLY | O_TRUNC | O_CREAT, 0644); // fd = 3
        // error check
        dup2(fd, 2);
        close(fd);

        // input redirection
        fd = open("in.txt", O_RDONLY); // fd = 3
        // error check
        dup2(fd, 0);
        close(fd);

        err = execlp("./demo37.out", "demo37.out", NULL); 
        if(err < 0) {
            perror("exec() failed");
            _exit(1);
        }
    }
    waitpid(-1, &s, 0);
    printf("parent finished!\n");
    return 0;
}

// terminal> gcc demo37.c -o demo37.out
// terminal> gcc demo39.c
// terminal> echo "12 0" > in.txt
// terminal> ./a.out


