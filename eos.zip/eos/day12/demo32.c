#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig, siginfo_t *si, void *param) {
    printf("SIGINT caught %d, sent by %d\n", si->si_signo, si->si_pid);
    printf("Current process id: %d\n", getpid());
}

int main() {
    int ret, i = 1;
    struct sigaction sa;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    while(1) {
        printf("running: %d\n", i++);
        sleep(1);
    }
    return 0;
}

// terminal1> gcc demo32.c
// terminal1> ./a.out

// terminal2> pkill -2 a.out
// terminal2> pkill -2 a.out
// terminal2> pkill -9 a.out

