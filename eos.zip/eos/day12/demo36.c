#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig) {
    int i;
    for(i=1; i<=5; i++) {
        printf("SIGINT handled!\n");
        sleep(1);
    }
}

int main() {
    struct sigaction sa;
    int i, ret;
    sigset_t set;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    sigfillset(&sa.sa_mask); // use this sigmask when handler is running
    ret = sigaction(SIGINT, &sa, NULL);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    printf("waiting for any signal.\n");
    pause();    // wait for any signal who has some defalt action or user-defined action

    printf("bye, bye!\n");
    return 0;
}








