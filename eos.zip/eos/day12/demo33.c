#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig) {
    printf("SIGINT handled!\n");
}

int main() {
    struct sigaction sa;
    int i, ret;
    sigset_t set, oldset;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    sigemptyset(&set);          // 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000
    sigaddset(&set, SIGINT);    // 01000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000
    sigaddset(&set, SIGTERM);   // 01000000 00000010 00000000 00000000 00000000 00000000 00000000 00000000
    ret = sigprocmask(SIG_SETMASK, &set, &oldset);
    if(ret < 0) {
        perror("sigprocmask() failed");
        _exit(2);
    }
    printf("SIGINT & SIGTERM is masked!\n");

    for(i=1; i<=10; i++) {
        printf("main: %d\n", i);
        sleep(1);
    }

    sigemptyset(&set);          // 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000
    sigaddset(&set, SIGTERM);   // 00000000 00000010 00000000 00000000 00000000 00000000 00000000 00000000
    ret = sigprocmask(SIG_SETMASK, &set, &oldset);
    if(ret < 0) {
        perror("sigprocmask() failed");
        _exit(2);
    }
    printf("SIGINT is unmasked!\n");

    for(i=11; i<=15; i++) {
        printf("main: %d\n", i);
        sleep(1);
    }

    sigemptyset(&set);          // 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000
    ret = sigprocmask(SIG_SETMASK, &set, &oldset);
    if(ret < 0) {
        perror("sigprocmask() failed");
        _exit(2);
    }
    printf("SIGTERM is unmasked!\n");

    for(i=16; i<=18; i++) {
        printf("main: %d\n", i);
        sleep(1);
    }
    return 0;
}








