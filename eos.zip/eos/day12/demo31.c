#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void sigchld_handler(int sig) {
    int s;
    waitpid(-1, &s, 0);
    printf("child exit status: %d\n", WEXITSTATUS(s));
}

int main() {
    int ret, i;
    void (*oldsigchld_handler)(int);
    struct sigaction sa_new, sa_old;

    //oldsigchld_handler = signal(SIGCHLD, sigchld_handler);
    memset(&sa_old, 0, sizeof(struct sigaction));
    memset(&sa_new, 0, sizeof(struct sigaction));
    sa_new.sa_handler = sigchld_handler;
    ret = sigaction(SIGCHLD, &sa_new, &sa_old);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    ret = fork();
    if(ret == 0) {
        // child process
        for(i=1; i<=15; i++) {
            printf("child: %d\n", i);
            sleep(1);
        }
        _exit(0);
    }

    // parent process
    for(i=1; i<=30; i++) {
        printf("parent: %d\n", i);
        sleep(1);
    }
    return 0;
}


