#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int ret, s, err;
    printf("parent started!\n");
    // parent OFDT: 0 (stdin), 1 (stdout), 2 (stderr) --> terminal
    ret = fork();
    if(ret == 0) {
        // child OFDT: 0 (stdin), 1 (stdout), 2 (stderr) --> terminal
        int fd = open("out.txt", O_WRONLY | O_TRUNC | O_CREAT, 0644); // fd = 3
        // child OFDT: 0 (stdin), 1 (stdout), 2 (stderr), 3 (out.txt)
        close(1);
        // child OFDT: 0 (stdin), 1 (stdout closed), 2 (stderr), 3 (out.txt)
        dup(fd);
        // child OFDT: 0 (stdin), 1 (out.txt), 2 (stderr), 3 (out.txt)
        close(fd);
        // child OFDT: 0 (stdin), 1 (out.txt), 2 (stderr), 3 (out.txt closed)
        
        err = execlp("ls", "ls", "-l", NULL); // by default output on 1 (stdout) --> redirected to --> 3 (out.txt)
        if(err < 0) {
            perror("exec() failed");
            _exit(1);
        }
    }
    waitpid(-1, &s, 0);
    printf("parent finished!\n");
    return 0;
}


