#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig) {
    printf("SIGINT handled!\n");
}

int main() {
    struct sigaction sa;
    int i, ret;
    sigset_t set;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    printf("waiting for any signal.\n");
    //sigemptyset(&set);  // 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000
    //sigsuspend(&set);

    pause();    // wait for any signal who has some defalt action or user-defined action

    printf("bye, bye!\n");
    return 0;
}








