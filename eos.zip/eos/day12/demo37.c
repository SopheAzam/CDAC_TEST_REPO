#include <stdio.h>

int main() {
    int num1, num2, result;
    scanf("%d%d", &num1, &num2);    // <-- stdin
    result = num1 * num2;
    printf("multiply result = %d\n", result);   // --> stdout
    if(num2 == 0)
        fprintf(stderr, "divide by zero error.\n"); // --> stderr
    else {
        result = num1 / num2;
        fprintf(stdout, "divide result = %d\n", result); // --> stdout
    }
    return 0;
}

