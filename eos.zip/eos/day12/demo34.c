#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

void sigint_handler(int sig) {
    printf("SIGINT handled!\n");
}

int main() {
    struct sigaction sa;
    int i, ret;
    sigset_t set;

    memset(&sa, 0, sizeof(struct sigaction));
    sa.sa_handler = sigint_handler;
    ret = sigaction(SIGINT, &sa, NULL);
    if(ret < 0) {
        perror("sigaction() failed");
        _exit(1);
    }

    // pause current process for SIGINT signal -- mask all other signals
        // step 1: set new mask with SIGINT unmasked and all other masked. 10111111 11111111 11111111 11111111 11111111 11111111 11111111 11111111
        // step 2: pause the execution of current process until the unmasked signal is arrived.
        // step 3: handle the unmasked signal (user-defined or default) and set the old mask again
    // this can be done in single step using sigsuspend()
    
    printf("waiting for SIGINT signal.\n");
    sigfillset(&set);
    sigdelset(&set, SIGINT);    
    sigsuspend(&set);

    printf("bye, bye!\n");
    return 0;
}








