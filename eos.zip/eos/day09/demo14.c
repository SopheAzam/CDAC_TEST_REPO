#include <unistd.h>
#include <stdio.h>

// count max processes
int main() {
    int count, ret;
    count = 0;
    while(1) {
        ret = fork();
        if(ret == -1)
            break;
        if(ret == 0) {
            sleep(10);
            _exit(0);
        } else {
            count++;
        }
    }
    printf("max child processes: %d\n", count);
    // TODO release PCB of child processes
    return 0;
}
