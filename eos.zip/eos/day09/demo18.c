#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

// wait() syscall
int main() {
    int i, pid, ret, s;
    printf("program started!\n");
    pid = fork();
    if(pid == 0) {
        printf("child: fork() returned: %d\n", pid);
        for(i=0; i<7; i++) {
            printf("child: %d\n", i);
            sleep(1);
        }
        printf("child: program completed!\n");
        _exit(0);
    }
    else {
        printf("parent: fork() returned: %d\n", pid);
        for(i=0; i<15; i++) {
            printf("parent: %d\n", i);
            sleep(1);
            ret = waitpid(pid, &s, WNOHANG);
            if(ret > 0)
                printf("child exit status: %d\n", WEXITSTATUS(s));
        }
        printf("parent: program completed!\n");
    }
    return 0;
}
