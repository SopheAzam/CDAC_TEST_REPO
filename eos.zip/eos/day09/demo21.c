#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    char *ptr, cmd[1024];
    char *args[32];
    int s, i, ret, err;

    while(1) {
        printf("cmd> ");
        gets(cmd);
        i = 0;
        ptr = strtok(cmd, " \t");
        args[i] = ptr;
        i++;
        do {
            ptr = strtok(NULL, " \t");
            args[i] = ptr;
            i++;
        } while(ptr != NULL);

        //for(i=0; args[i]!=NULL; i++)
        //    puts(args[i]);

        if(strcmp(args[0], "exit") == 0)
            break;
        else if(strcmp(args[0], "cd") == 0)
            chdir(args[1]);
        else if(strcmp(args[0], "wish") == 0)
            printf("Hello, User!\n");
        else {
            ret = fork();
            if(ret == 0) {
                err = execvp(args[0], args);
                if(err < 0) {
                    perror("bad command");
                    _exit(1);
                }
            }
            else
                wait(&s);
        }
    }
    return 0;
}

