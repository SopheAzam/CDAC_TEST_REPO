#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[], char *envp[]) {
    int s, ret, err;
    printf("parent started!\n");
    ret = fork();
    if(ret == 0) {
        //err = execl("/usr/bin/firefox", "firefox", "https://www.google.com", NULL);
        
        //char *args[] = { "firefox", "https://www.google.com", NULL };
        //err = execv("/usr/bin/firefox", args);

        //err = execlp("firefox", "firefox", "https://www.google.com", NULL);

        //char *args[] = { "firefox", "https://www.google.com", NULL };
        //err = execvp("firefox", args);

        //err = execle("/usr/bin/firefox", "firefox", "https://www.google.com", NULL, envp);

        //char *args[] = { "firefox", "https://www.google.com", NULL };
        //err = execve("/usr/bin/firefox", args, envp); // syscall(2)

        char *args[] = { "firefox", "https://www.google.com", NULL };
        err = execvpe("firefox", args, envp);

       if(err < 0) {
            perror("exec() failed");
            _exit(1);
        }
    }
    else {
        wait(&s);
        printf("child exit status: %d\n", WEXITSTATUS(s));
    }
    printf("parent finished!\n");
    return 0;
}

/*
To use execvpe() define _GNU_SOURCE.
way 1:
    #define _GNU_SOURCE --> at the beginning of the file.
way 2:
    gcc -D_GNU_SOURCE demo19.c
*/